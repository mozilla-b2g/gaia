# Yule Log

To create a new Yule Log package for production:

```bash
make log
```

For -dev:

```bash
NAME='Dev' DOMAIN='marketplace-dev.allizom.org' make log
```

For stage:

```bash
NAME='Stage' DOMAIN='marketplace.allizom.org' make log
```
