var path = location.href.substr(0, location.href.lastIndexOf("/") + 1);

var req = navigator.mozApps.installPackage(path + "package.manifest");

req.onsuccess = function() {
	alert(this.result.origin);
};
req.onerror = function() {
	alert(this.error.name);
};