var settings = window.localStorage.getItem("settings") && JSON.parse(window.localStorage.getItem("settings"));

if (settings && settings.welcomeDisclaimerAccepted) {
	location.href = "index.html?platform=firefox_app&back=true#action=search&bmk=1";
} else {
	location.href = "index.html?platform=firefox_app&back=true#action=welcome&bmk=1";
}