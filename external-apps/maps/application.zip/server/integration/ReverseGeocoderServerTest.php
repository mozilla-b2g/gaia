<?php

require_once("../config.php");
require_once("../curl.php");

require_once("JsonSchema.php");
require_once("testconfig.php");

class ReverseGeocoderServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = strtr(REVERSEGEOURL, array(
            "<appId>"   => TEST_APP_ID,
            "<appCode>" => TEST_APP_CODE,
            "<lat>"     => "50.1115118",
            "<lon>"     => "8.6805059"
        ));
        $this->response = curl($requestURL);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testStatus() {
        $this->assertEquals(200, $this->response->status, "Response status code should be 200");
    }

    public function testContentType() {
        $this->assertContains("application/json", $this->response->headers["Content-Type"]);
    }

    public function testSchema() {
        $expectedSchema = json_decode('{
            "Response": {
                "View": [{
                    "Result": [{
                        "Location": {
                            "Address": {
                                "Label": "label"
                            }
                        }
                    }]
                }]
            }
        }', TRUE);

        $data = json_decode($this->response->body, TRUE);

        $this->assertTrue(JsonSchema::validate($data, $expectedSchema), "Response JSON should be valid");
    }

    protected function tearDown() {}
}
