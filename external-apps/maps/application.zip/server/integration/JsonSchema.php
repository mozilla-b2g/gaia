<?php

class JsonSchema {

    public static $error;

    private static function is_assoc($arr) {
        return (array_diff_key($arr, array_keys(array_keys($arr))));
    }

    /**
     * checks the existence of array keys according to a given schema
     * @param array $data
     * @param array $schema
     * @return boolean
     */
    public static function validate($data, $schema, $prefix = "") {
        // clear error mesage
        self::$error = "";

        // if schema is null (usualy a result of failed json parsing)
        if ($schema === NULL) {
            self::$error = "Expected JSON likely to be broken!";
            return FALSE;
        }

        // if schema is a scalar, everything else passes
        if (!is_array($schema)) {
            return TRUE;
        }

        // associative schema
        if (self::is_assoc($schema)) {
            // schema is an array, so data has to be as well
            if (!is_array($data)) {
                self::$error = "array or object expected for '$prefix' but scalar found";
                return FALSE;
            }

            if (!self::is_assoc($data)) {
                self::$error = "object expected for '$prefix' but array found";
                return FALSE;
            }

            foreach ($schema as $k=>$foo) {
                $pk = $prefix ? "$prefix.$k" : $k;
                if (!isset($data[$k])) {
                    self::$error = "key '$pk' not found";
                    return FALSE;
                }
                if (!self::validate($data[$k], $schema[$k], $pk)) {
                    return FALSE;
                }
            }

            return TRUE;
        }

//        // schema is numeric, so data has to be as well
//        if (self::is_assoc($data)) {
//            self::$error = "array expected for '$prefix' but object found";
//            return FALSE;
//        }

        // WORKAROUND [jmarsch] for backend serialization bug
        // if data is a scalar, make it an array.
        if (self::is_assoc($data) || !is_array($data)) {
            $data = array($data);
        }

        // find somewhere in numeric array
        for ($s = 0; $s < count($schema); $s++) {
            $found = FALSE;
            for ($d = 0; $d < count($data); $d++) {
                if (self::validate($data[$d], $schema[$s], $prefix ? $prefix."[]" : "[]")) {
                    $found = TRUE;
                    break;
                }
            }

            if (!$found) {
                return FALSE;
            }
        }

        return TRUE;
    }
}