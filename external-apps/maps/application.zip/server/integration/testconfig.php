<?php

define("EXPRESPONSETIME", 6);

define("TEST_APP_ID", "FLq0p5qyl-3-jTx2ANEi");
define("TEST_APP_CODE", "0d03vSmNAytGsZfItsVBQw");
