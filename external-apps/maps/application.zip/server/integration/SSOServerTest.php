<?php

require_once("../config.php");
require_once("../curl.php");
require_once("testconfig.php");

class SSOServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        global $SSO_CONFIG;
        $url = $SSO_CONFIG["ssoBaseUrl"];
        $this->response = curl($url);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testStatus() {
        $this->assertEquals(200, $this->response->status, "Response status code should be 200");
    }

    public function testContentType() {
        $this->assertContains("text/html", $this->response->headers["Content-Type"]);
    }

    protected function tearDown() {}
}