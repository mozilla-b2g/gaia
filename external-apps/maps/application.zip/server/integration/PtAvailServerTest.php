<?php

require_once("../config.php");
require_once("../curl.php");
require_once("JsonSchema.php");

class PtAvailServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
       $requestURL = strtr(PUBTRANSDISCLAIMERURL, array(
            "<key>"  => "Qechac55zebruBa5aStEvet2eqayA76U"
        ));
        $this->response = curl($requestURL);
    }


   public function testResponseTime() {
       $this->assertLessThanOrEqual(2, $this->response->time, "Response should be faster than 2s");
   }

   public function testStatus() {
       $this->assertEquals(200, $this->response->status, "Response status code should be 200");
   }

   public function testContentType() {
       $this->assertContains("application/json", $this->response->headers["Content-Type"]);
   }

   public function testSchema() {
       $expectedSchema = json_decode('{
            "bboxResponse": {
                "region": [{
                    "metaInfo": 1,
                    "area": [{
                        "@type": 1
                    }]
                }]
            }
        }', TRUE);

       $data = json_decode($this->response->body, TRUE);
       $this->assertTrue(JsonSchema::validate($data, $expectedSchema), "Response JSON should be valid");
   }

    protected function tearDown() {}

}