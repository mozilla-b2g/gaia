<?php

require_once("../config.php");
require_once("../curl.php");
require_once("testconfig.php");

class NPSServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = "http://cpq.nokia.com/public/monitoring.php";
        $this->response = curl($requestURL);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 3s");
    }

    public function testContentOK() {
        $this->assertContains("Test OK", $this->response->body);
    }

    protected function tearDown() {}
}
