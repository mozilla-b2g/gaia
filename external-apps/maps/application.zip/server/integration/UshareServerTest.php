<?php

require_once("../config.php");
require_once("../curl.php");
require_once("JsonSchema.php");
require_once("testconfig.php");

class UshareServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = USHAREURL ."auth/session";
        $this->response = curl($requestURL);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testContentType() {
        $this->assertContains("application/json", $this->response->headers["Content-Type"]);
    }

    public function testSchema() {
        $expectedSchema = json_decode('{
            "result": {
                "status": 1
            }
        }', TRUE);

        $data = json_decode($this->response->body, TRUE);

        $this->assertTrue(JsonSchema::validate($data, $expectedSchema), "Response JSON should be valid");
    }

    protected function tearDown() {}
}