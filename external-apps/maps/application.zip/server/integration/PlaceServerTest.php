<?php

require_once("../config.php");
require_once("../curl.php");

require_once("JsonSchema.php");
require_once("testconfig.php");

class PlaceServerTest extends PHPUnit_Framework_TestCase {

    private $response;

    protected function setUp() {
        $requestURL = strtr(DETAILSURL, array(
            "<placeId>"         => "276u336y-6537239b7f8d45a7aefc8fb621da3e3f",
            "<appId>"           => TEST_APP_ID,
            "<appCode>"         => TEST_APP_CODE,
            "<imageDimensions>" => "h70,w918-h918"
        ));
        $this->response = curl($requestURL);
    }

    public function testResponseTime() {
        $this->assertLessThanOrEqual(EXPRESPONSETIME, $this->response->time, "Response should be faster than 2s");
    }

    public function testStatus() {
        $this->assertEquals(200, $this->response->status, "Response status code should be 200");
    }

    public function testContentType() {
        $this->assertContains("application/json", $this->response->headers["Content-Type"]);
    }

    public function testSchema() {
        $expectedSchema = json_decode('{
            "placeId": 1,
            "name": 1,
            "categories": [{ "id": 1 }],
            "icon": 1,
            "location": { "position": [0,1], "address": { "text": 1 } },
            "ratings": { "average": 1, "count": 1 }
        }', TRUE);

        $data = json_decode($this->response->body, TRUE);

        $this->assertTrue(JsonSchema::validate($data, $expectedSchema), "Response JSON should be valid");
    }

    protected function tearDown() {}
}
