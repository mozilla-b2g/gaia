<?php
/*
 * global functions for our server code
 */

/**
 * Checks if a string represents a valid JS identifier
 * @see http://samples.geekality.net/js-identifiers/
 *
 * @param String $subject String to check if it is a valid JS identifier
 * @return TRUE if $subject is a valid JS identifier, FALSE otherwise
 */
function is_valid_js_identifier($subject)
{
    $identifier_syntax
      = '/^[$_\p{L}][$_\p{L}\p{Mn}\p{Mc}\p{Nd}\p{Pc}\x{200C}\x{200D}]*+$/u';

    $reserved_words = Array('break', 'do', 'instanceof', 'typeof', 'case',
        'else', 'new', 'var', 'catch', 'finally', 'return', 'void', 'continue',
        'for', 'switch', 'while', 'debugger', 'function', 'this', 'with',
        'default', 'if', 'throw', 'delete', 'in', 'try', 'class', 'enum',
        'extends', 'super', 'const', 'export', 'import', 'implements', 'let',
        'private', 'public', 'yield', 'interface', 'package', 'protected',
        'static', 'null', 'true', 'false');

    return preg_match($identifier_syntax, $subject)
        && ! in_array(mb_strtolower($subject, 'UTF-8'), $reserved_words);
}

/**
 * Will exit the control flow with HTTP response code 500 if the given identifier is invalid
 * @param String $jsident Javascript identifier name
 */
function exit_on_invalid_jsidentifier($jsident) {
    if (!is_valid_js_identifier($jsident)) {
        header("HTTP/1.0 500 Unsupported parameter");
        echo "invalid";
        exit;
    }
}

/**
 * Enables CORS functionality by adding headers to the response
 */
function enableCORS() {
    /*
     * we do not support CORS currently
     *
    // enable CORS
    $allowedOrigin = isset($_SERVER["HTTP_ORIGIN"]) ? $_SERVER["HTTP_ORIGIN"] : "*";
    // TODO [chrheinr] - sanitize $allowedOrigin
    header("Access-Control-Allow-Origin: $allowedOrigin");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Max-Age: 1728000");
    header("Access-Control-Allow-Credentials: true");
    */
}

/**
 * Adds clientId and serviceId to the request parameters
 *
 * @param Array $reqParam associative array of the request parameters, new params for serviceId, clientId
 *                 will be added
 */
function addClientAndServiceParams(&$reqParam) {
    if (!isset($reqParam["serviceId"])){
        $reqParam["serviceId"] = "maps";
    }
    if (!isset($reqParam["clientId"])){
        $reqParam["clientId"] = "mHTML5";
    }
}