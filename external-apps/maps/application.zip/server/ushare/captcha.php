<?php
require_once('../config.php');
require_once("../functions.php");
require_once('../curl.php');

// no CORS support currently
// enableCORS();

$isJsonp = isset($_REQUEST['jsonp']);
$callbackFn = $isJsonp ? $_REQUEST["jsonp"] : "myCallback";
// exit immediately if callback is not valid JS id
exit_on_invalid_jsidentifier($callbackFn);

$data = array();
$supportedParams = array("captchaWidth", "captchaHeight", "sectoken", "version");
foreach ($supportedParams as $param) {
    if (isset($_REQUEST[$param])) {
        $data[$param] = $_REQUEST[$param];
    }
}

// client and service params
addClientAndServiceParams($data);

$result = curl(array(
    "method" => "POST",
    "url" => USHAREURL ."auth/captcha",
    "data" => $data,
    "timeout" => 5,
    "cookies" => $_COOKIE
));


header("Content-Type: ". ($isJsonp ? "application/javascript; charset=utf-8" : "application/json; charset=utf-8"));


// return jsonp plain json
if ($isJsonp) {
    echo $callbackFn ."(". $result->body .");";
} else {
    echo $result->body;
}