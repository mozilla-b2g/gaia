<?php
session_start();

if (!$_SESSION['logged_in']) {
    $_SESSION['logged_in'] = true;

    print '<script>window.location.href = ';

    print "'nok://login/cookies[]=". urlencode("NokiaSessionId=". $_COOKIE['NokiaSessionId']) ."&cookies[]=". urlencode("NOALastLogin=". $_COOKIE['NOALastLogin'])."&cookies[]=". urlencode("s_vi=". $_COOKIE['s_vi']) ."&data=". $_GET["data"] ."'";

    print '; setTimeout(function () { window.close(); }, 300); </script>';
} else {
    $_SESSION['logged_in'] = false;

    header('Location: http://www.nokia.com/');
}