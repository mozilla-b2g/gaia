<?php

// set include path to find library folder
set_include_path(realpath("./library/").PATH_SEPARATOR.get_include_path());

require_once("Nokia/Sso/WebOauth2.php");
require_once("../config.php");

$sso = Nokia_Sso_WebOauth2::getInstance();
$sso->setConfig($SSO_CONFIG);

$sso->startSession(); // start a session if storage type is 'phpsession'
$sso->createSession();

if (!isset($_SESSION["accesstokenInfo"])) {
    header("HTTP/1.0 401 Unauthorized");
    exit;
}

$data = array(
    "validuntil"   => $_SESSION["accesstokenInfo"]["validuntil"]*1,
    "greetingname" => $_SESSION["accesstokenInfo"]["greetingname"],
    "accountid"    => $_SESSION["accesstokenInfo"]["accountid"],
    "legacy_token" => $_SESSION["accesstokenInfo"]["legacy_token"]
);

if (!isset($_GET["jsonp"])) {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode($data);
    exit;
}

header("Content-Type: application/javascript; charset=utf-8");
echo $_GET["jsonp"]."(".json_encode($data).");";
exit;
