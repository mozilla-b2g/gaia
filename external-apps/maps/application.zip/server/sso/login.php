<?php
//*** use this file to force a login in any case
error_reporting(E_ALL);
// set include path to find library folder
set_include_path(realpath("./library/").PATH_SEPARATOR.get_include_path());

require_once("Nokia/Sso/WebOauth2.php");
require_once("../config.php");

if (isset($_GET['wrapped'])) {
    $SSO_CONFIG['redirect_uri'] = $SSO_CONFIG['redirect_uri_wrapped'];
}

$sso = Nokia_Sso_WebOauth2::getInstance();
$sso->setConfig($SSO_CONFIG);
$sso->forceLogin(array("ui"=>"touch"));
