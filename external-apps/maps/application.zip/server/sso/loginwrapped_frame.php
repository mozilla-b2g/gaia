<?php
foreach($_GET['cookies'] as $cookie) {
    $data = explode("=", urldecode($cookie));

    setcookie($data[0], $data[1], time()+60*60, "/", $_SERVER['SERVER_NAME']);
}

?>
<script>
window.top.postMessage('<?php echo $_GET['data'] ?>', "*");
</script>
