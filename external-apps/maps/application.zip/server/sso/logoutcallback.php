<?php
if (isset($_GET["wrapped"])) {
    session_start();

    if (!$_SESSION['logged_out']) {
        $_SESSION['logged_out'] = true;
        ?>
        <script>window.location.href = "nok://logout"; setTimeout(function () { window.close(); }, 300);</script>
        <?php
    } else {
        $_SESSION['logged_out'] = false;
        ?>
        <script>window.location.href = "http://www.nokia.com";</script>
        <?php
    }
} elseif (isset($_GET["jsonp"])) {
    header("Content-Type: application/javascript; charset=utf-8");
    echo $_GET["jsonp"]."();";
} else {
    header("Content-Type: application/json; charset=utf-8");
//    header("HTTP/1.0 204 No Content");
}
