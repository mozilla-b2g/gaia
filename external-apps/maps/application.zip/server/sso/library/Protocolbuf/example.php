<?php
// set include path to find 'library' folder
set_include_path( realpath("./../../library/") . PATH_SEPARATOR . get_include_path() );
require_once('Protocolbuf/parser/pb_parser.php');
$test = new PBParser();
$test->parse('OAuth2AccessToken.proto');