<?php
/** Nokia_Sso_Api */
require_once 'Nokia/Sso/Api.php';

/**
 * NoA server PHP SDK - This class contains all API implementation
 * for Identity Federation.
 */
class Nokia_Api_IdentityFederation extends Nokia_Sso_Api
{

	private $_configApi = array(
       'ssoUrlRetrieveExternalIdentity'  => '/rest/1.0/externalIdentities/%s/external/%t',
	   'ssoUrlRetrieveExternalIdentities'  => '/rest/1.0/externalIdentities/%s',
	   'ssoUrlRetrieveuserProfile'  => '/rest/1.0/externalIdentities/%s/profile/%t',
	   'ssoUrlRetrievePartnerToken'  => '/rest/1.0/partnertokens/%s',
	   'ssoUrlAuthenticateWithPartnerToken'  => '/rest/1.0/partnertokens',
	   'ssoUrlCreateAccessToken' => '/rest/1.0/tokens/%s/external',
	   'ssoUrlLinkAccountWithExternalIdentity' => '/rest/1.0/externalIdentities/%s',
	   'ssoUrlCreateShadowAccount'  => '/rest/1.0/externalIdentities',
	   'ssoUrlRemoveExternalIdentity'   	=> '/rest/1.0/externalIdentities/%s'
	   );

	   /**
	    * Key used at APC caching (if available)
	    * @var string $apcKey
	    */
	   static public $apcKey = "NokiaApiIdentityFederationSingleton";

	   /**
	    * Singleton instance of Nokia_Api
	    * @var Nokia_Api_IdentityFederation $_instance
	    */
	   static private $_instance;

	   /**
	    * Get singleton intance
	    * @return Nokia_Api_IdentityFederation
	    */
	   static public function getInstance()
	   {
	   	// check if cache enabled
	   	$cache = function_exists('apc_store');
	   	// check if instance exists already
	   	if (!(self::$_instance instanceof self))
	   	{
	   		self::$_instance = new self();
	   		if ($cache)
	   		{ // store into cache if available
	   			apc_store(Nokia_Api_IdentityFederation::$apcKey, self::$_instance);
	   		}
	   	}
	   	// return instance from cache if available
	   	return $cache ? apc_fetch(Nokia_Api_IdentityFederation::$apcKey) : self::$_instance;
	   }

	   /**
	    * Set configuration array.
	    * @see trunk/library/Nokia/Sso/Nokia_Sso_Api::setConfig()
	    */
	   public function setConfig(array $config)
	   {
	   	return parent::setConfig(array_merge($this->_configApi, $config));
	   }

	   /**
	    * Set tokenInfo as OAuthToken object
	    */
	   public function setTokeninfo($token)
	   {
	   	return parent::getTokenInfo($token);
	   }

	   /**
	    * API to fetch external identity information corresponding to the partnerId passed.
	    * @access Public
	    * @param String $accountId Account ID
	    * @param string $partnerId Partner ID
	    * @return Simple XML Object
	    */
	   public function fetchExternalIdentity($accountId, $partnerId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id is Null");

	   	if(empty($partnerId))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");

	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace(array('%s','%t'),array(trim($accountId),trim($partnerId)),$this->_config['ssoUrlRetrieveExternalIdentity'])
	   	);
	   }

	   /**
	    * API to create an Access Token with the help of external identity information along with client Key.
	    * @access Public
	    * @param Array ExternalToken as externalTokenName, externalTokenValue, externalTokenValidUntil
	    * @param Array $data as externalId , ClientKey
	    * @return Simple XML Object
	    */
	   public function createAccessToken(array $data, array $externalToken = null)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<externalIdentityTokenCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<externalID></externalID>
</externalIdentityTokenCreationRequest>
XML;
	   	$xml = simplexml_load_string($xmlString);

	   	if(empty($data['externalID']))
	   	throw new Exception("Invalid Message Format::External Id is Null");

	   	$xml->externalID = $data['externalID'];

	   	if(!empty($externalToken))
	   	{
	   		foreach($externalToken as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$externalTokenArrayNode = $xml->addChild('externalToken');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$externalTokenArrayNode->addChild($k,$v);
	   			}

	   		}
	   		if(!is_array(current($externalToken)))
	   		$externalTokenNode = $xml->addChild('externalToken');
	   		if(!empty($externalToken['externalTokenName']))
	   		$externalTokenNode->addChild('externalTokenName',$externalToken['externalTokenName']);
	   		if(!empty($externalToken['externalTokenValue']))
	   		$externalTokenNode->addChild('externalTokenValue',$externalToken['externalTokenValue']);
	   		if(!empty($externalToken['externalTokenValidUntil']))
	   		$externalTokenNode->addChild('externalTokenValidUntil',$externalToken['externalTokenValidUntil']);
	   	}

	   	if(!empty($data['clientKey']))
	   	{
	   		$xml->addChild('clientKey');
	   		$xml->clientKey = $data['clientKey'];
	   	}

	   	if(empty($data['partnerID']))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");

	   	$responseXml = $this->requestCreateAccessToken($data['partnerID'],$xml);

	   	$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
	    $responseXml->userInfo->email = $unicode_email;
	    return $responseXml;

	   }


	   /**
	    * API to fetch External identities information
	    * @access Public
	    * @param String AccountId
	    * @return Simple XML Object
	    */
	   public function fetchExternalIdentities($accountId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id is Null");
	   	else
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', trim($accountId), $this->_config['ssoUrlRetrieveExternalIdentities'])
	   	);
	   }

	   /**
	    * API to fetch user profile information
	    * @access Public
	    * @param String $partnerId
	    * @param String $externalId
	    * @return Simple XML Object
	    */
	   public function fetchUserProfileInfo($partnerId, $externalId)
	   {
	   	if(empty($partnerId))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");

	   	if(empty($externalId))
	   	throw new Exception("Invalid Message Format::External Id is Null");

	   	$responseXml = $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace(array('%s','%t'),array(trim($partnerId),trim($externalId)),$this->_config['ssoUrlRetrieveuserProfile'])
	   	);

	   	$unicode_email = $this->idna_toUnicode($responseXml->profile->email);
	    $responseXml->profile->email = $unicode_email;
	    return $responseXml;
	   }

	   /**
	    * API to create shadow account
	    * @access Public
	    * @param Array $data as PartnerId, ExternalId, externalNameId, clientKey, sendVerification and request as ip, userAgent
	    * @param Array $marketingConsent as email, mobile, serviceId
	    * @param Array $externalToken as externalTokenName, externalTokenValue, externalTokenValidUntil
	    * @return Simple XML Object
	    */
	   public function createShadowAccount(array $data, array $marketingConsent = null, array $externalToken = null)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<shadowAccountCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<partnerID></partnerID>
<externalID></externalID>
</shadowAccountCreationRequest>
XML;
	   	$xml = simplexml_load_string($xmlString);

	   	if(empty($data['partnerID']))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");
	   	else
	   	$xml->partnerID = $data['partnerID'];

	   	if(empty($data['externalID']))
	   	throw new Exception("Invalid Message Format::External Id is Null");
	   	else
	   	$xml->externalID = $data['externalID'];

	   	if(!empty($externalToken))
	   	{
	   		foreach($externalToken as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$externalTokenArrayNode = $xml->addChild('externalToken');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$externalTokenArrayNode->addChild($k,$v);
	   			}

	   		}
	   		if(!is_array(current($externalToken)))
	   		$externalTokenNode = $xml->addChild('externalToken');
	   		if(!empty($externalToken['externalTokenName']))
	   		$externalTokenNode->addChild('externalTokenName',$externalToken['externalTokenName']);
	   		if(!empty($externalToken['externalTokenValue']))
	   		$externalTokenNode->addChild('externalTokenValue',$externalToken['externalTokenValue']);
	   		if(!empty($externalToken['externalTokenValidUntil']))
	   		$externalTokenNode->addChild('externalTokenValidUntil',$externalToken['externalTokenValidUntil']);
	   	}

	   	if(!empty($data['externalNameID']))
	   	{
	   		$xml->addChild('externalNameID');
	   		$xml->externalNameID = $data['externalNameID'];
	   	}

	   	if(!empty($data['userData']))
	   	{
	   		if(is_array($data['userData']))
	   		{
	   			$userDataArrayNode = $xml->addChild('userData');
	   			foreach ($data['userData'] as $key => $value)
	   			{
	   				if($key == 'password'){
	   					// Convert password value to base64 string
	   					$value = (string) base64_encode($data['userData'][$key]);
	   				}
	   				$userDataArrayNode->addChild($key, $value);
	   			}
	   		}
	   	}
	   	if(!empty($data['userData']['email']))
	   	{
		   	$ascii_email = $this->idna_toAscii($xml->userData->email);
		   	$xml->userData->email = $ascii_email;
	   	}else
	   	{
	   		throw new Exception("Invalid Message Format::Email Address required");
	   	}

	   	if(!empty($data['clientKey']))
	   	{
	   		$xml->addChild('clientKey');
	   		$xml->clientKey = $data['clientKey'];
	   	}

	   	if(!empty($marketingConsent))
	   	{
	   		foreach($marketingConsent as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$marketingConsentArrayNode = $xml->addChild('marketingConsent');
	   				foreach($val as $k=>$v)
	   				$marketingConsentArrayNode->addChild($k,$v);
	   			}
	   		}

	   		if(!empty($marketingConsent['email']) || !empty($marketingConsent['mobile'])  || !empty($marketingConsent['serviceId']))
	   		{
	   			$marketingConsentNode = $xml->addChild('marketingConsent');
	   			$marketingConsentNode->addChild('email',$marketingConsent['email']);
	   			$marketingConsentNode->addChild('mobile',$marketingConsent['mobile']);
	   			$marketingConsentNode->addChild('serviceId',$marketingConsent['serviceId']);
	   		}
	   	}

	   	if(!empty($data['sendVerification']))
	   	{
	   		$xml->addChild('sendVerification');
	   		$xml->sendVerification = $data['sendVerification'];
	   	}

	   	if(empty($data['request']['ip']))
	   	$ip = $_SERVER['REMOTE_ADDR'];
	   	else
	   	$ip = $data['request']['ip'];

	   	if(empty($data['request']['userAgent']))
	   	$userAgent = $_SERVER['HTTP_USER_AGENT'];
	   	else
	   	$userAgent = $data['request']['userAgent'];

	   	$responseXml = $this->requestCreateShadowAccount($xml,$ip, $userAgent);

	   	$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
	    $responseXml->userInfo->email = $unicode_email;
	    return $responseXml;
	   }

	   /**
	    * API to Link Account With External Identity.
	    * @access Public
	    * @param String $accountId
	    * @param Array $data as partnerID, externalID, externalNameID
	    * @param Array $externalToken as externalTokenName, externalTokenValue, externalTokenValidUntil
	    * @return null
	    */

	   public function linkAccountWithExternalIdentity($accountId, array $data , array $externalToken = null)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<accountLinkingRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<partnerID></partnerID>
<externalID></externalID>
</accountLinkingRequest>
XML;
	   	$xml = simplexml_load_string($xmlString);

	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id is Null");

	   	if(empty($data['partnerID']))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");
	   	else
	   	$xml->partnerID = $data['partnerID'];

	   	if(empty($data['externalID']))
	   	throw new Exception("Invalid Message Format::External Id is Null");
	   	else
	   	$xml->externalID = $data['externalID'];

	   	if(!empty($externalToken))
	   	{
	   		foreach($externalToken as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$externalTokenArrayNode = $xml->addChild('externalToken');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$externalTokenArrayNode->addChild($k,$v);
	   			}

	   		}
	   		if(!is_array(current($externalToken)))
	   		$externalTokenNode = $xml->addChild('externalToken');
	   		if(!empty($externalToken['externalTokenName']))
	   		$externalTokenNode->addChild('externalTokenName',$externalToken['externalTokenName']);
	   		if(!empty($externalToken['externalTokenValue']))
	   		$externalTokenNode->addChild('externalTokenValue',$externalToken['externalTokenValue']);
	   		if(!empty($externalToken['externalTokenValidUntil']))
	   		$externalTokenNode->addChild('externalTokenValidUntil',$externalToken['externalTokenValidUntil']);
	   	}

	   	if(!empty($data['externalNameID']))
	   	{
	   		$xml->addChild('externalNameID');
	   		$xml->externalNameID = $data['externalNameID'];
	   	}

	   	return $this->requestLinkkAccountWithExternalIdentity($accountId,$xml);

	   }

	   /**
	    * API to fetch partner token for YAHOO
	    * @access Public
	    * @param String $accountId
	    * @return Simple XML object
	    */
	   public function fetchPartnerToken($accountId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id is Null");
	   	else
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', trim($accountId), $this->_config['ssoUrlRetrievePartnerToken'])
	   	);
	   }

	   /**
	    * API to authenticate using partner token for YAHOO
	    * @access Public
	    * @param String $userName
	    * @param String $partnerToken from API call fetchPartnerToken()
	    * @param String $checkTerms
	    * @return Simple XML object
	    */
	   public function authenticateWithPartnerToken($partnerToken, $username, $checkTerms = 'false')
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<partnerTokenCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
</partnerTokenCreationRequest>
XML;

	   	$xml = simplexml_load_string($xmlString);
	   	$nonce = md5(microtime() . mt_rand()); //generate new nonce (different from request Authorization)
	   	$timestamp = time(); //generate timestamp
	   	//add more elements into xml
	   	$resourceId = '/accounts/' . $this->idna_toAscii($username) . '/';
	   	$digestAuthNode = $xml->addChild('digestAuth');
	   	$digestAuthNode->addChild('username', $this->idna_toAscii($username));
	   	$digestAuthNode->addChild('nonce', $nonce);
	   	$digestAuthNode->addChild('created', $timestamp);
	   	$passwordHash  = base64_encode(sha1($resourceId . $partnerToken, true));
	   	$digestAuth = base64_encode(sha1($nonce . $timestamp . $passwordHash, true));
	   	$digestAuthNode->addChild('digest', $digestAuth);

	   	$checkTermsNode = $xml->addChild('checkTerms', $checkTerms);
	   	$responseXml= $this->requestAuthenticateWithPartnerToken($xml);

	   	$unicode_email = $this->idna_toUnicode($responseXml->userProfile->email);
	   	$responseXml->userProfile->email = $unicode_email;
	   	return $responseXml;
	   }

	   /**
	    * API to remove external identity information
	    * @access Public
	    * @param String $accountID
	    * @param String $partnerID
	    * @param String $externalID
	    * @return null
	    */
	   public function removeExternalIdentity($accountId, $partnerID, $externalID)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<externalIdentityRemovalRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<partnerID></partnerID>
<externalID></externalID>
</externalIdentityRemovalRequest>
XML;
	   	$xml = simplexml_load_string($xmlString);

	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id is Null");

	   	if(empty($partnerID))
	   	throw new Exception("Invalid Message Format::Partner Id is Null");
	   	else
	   	$xml->partnerID = $partnerID;

	   	if(empty($externalID))
	   	throw new Exception("Invalid Message Format::External Id is Null");
	   	else
	   	$xml->externalID = $externalID;
	   	return $this->requestRemoveExternalIdentity($accountId,$xml);
	   }

	   /**
	    * Request for Authenticate With PartnerToken into Nokia Account.
	    * @access Private
	    * @param XML $xml
	    * @return SimpleXMLObject $xml
	    */

	   private function requestAuthenticateWithPartnerToken($xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlAuthenticateWithPartnerToken'],
            'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request to Link Account With External Identity into Nokia Account.
	    * @access Private
	    * @param String $accountId
	    * @param XML $xml
	    * @return null
	    */

	   private function requestLinkkAccountWithExternalIdentity($accountId,$xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', trim($accountId), $this->_config['ssoUrlLinkAccountWithExternalIdentity']),
            'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request to create shadow account into Nokia Account.
	    * @access Private
	    * @param String $ip
	    * @param String $userAgent
	    * @param XML $xml
	    * @return SimpleXMLObject $xml
	    */

	   private function requestCreateShadowAccount($xml,$ip, $userAgent)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlCreateShadowAccount'],
            'PUT',
	   	array(
                'XMLContent' => $xml->asXml()
	   	),
	   	array( //array of extra headers (original user)
                'X-Nokia-Original-User-IP: ' . $ip,
                'X-Nokia-Original-User-Agent: ' . $userAgent
	   	)
	   	);
	   }

	   /**
	    * Request to Remove External Identity from Nokia Account.
	    * @access Private
	    * @param String $accountId
	    * @param XML $xml
	    * @return null
	    */

	   private function requestRemoveExternalIdentity($accountId,$xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlRemoveExternalIdentity']),
            'DELETE',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)

	   	);
	   }

	   /**
	    * Request to create Access Token into Nokia Account.
	    * @access Private
	    * @param String $partnerId
	    * @param XML $xml
	    * @return null
	    */

	   private function requestCreateAccessToken($partnerId,$xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', trim($partnerId), $this->_config['ssoUrlCreateAccessToken']),
            'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }
}
?>