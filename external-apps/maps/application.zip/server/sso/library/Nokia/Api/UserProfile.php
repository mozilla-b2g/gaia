<?php
/** Nokia_Sso_Api */
require_once 'Nokia/Sso/Api.php';

/**
 * NoA server PHP SDK - This class contains all API implementation
 * related to user profile.
 */
class Nokia_Api_UserProfile extends Nokia_Sso_Api
{

	private $_configApi = array(
       'ssoUrlUserProfile'  => '/rest/1.0/accounts/%s/profile',
       'ssoUrlUserInfo'     => '/rest/1.0/accounts/%s/info',
	   'ssoUrlUserContact'  => '/rest/1.0/accounts/%s/contacts',
	   'ssoUrlUpdateUserContact' => '/rest/1.0/accounts/%s/contacts',
	   'ssoUrlUserMarketingConsent' => '/rest/1.0/accounts/%s/marketing/%t',
	   'ssoUrlQueryConsentVariant' => '/rest/1.0/consentqueryvariant',
	   'ssoUrlUserTermsAcceptanceInfo' => '/rest/1.0/terms/%s',
	   'ssoUrlVerifyToken'  => '/rest/1.0/contactsverification/%t',
	   'ssoUrlSendEmailMobileVerfication' => '/rest/1.0/accounts/%s/sendverifications',
	   'ssoUrlContactsverification'	=> '/rest/1.0/accounts/%s/contactsverification'
	   );

	   /**
	    * Key used at APC caching (if available)
	    * @var string $apcKey
	    */
	   static public $apcKey = "NokiaApiUserProfileSingleton";

	   /**
	    * Singleton instance of Nokia_Api
	    * @var Nokia_Api_UserProfile $_instance
	    */
	   static private $_instance;

	   /**
	    * Get singleton intance
	    * @return Nokia_Api_UserProfile
	    */
	   static public function getInstance()
	   {
	   	// check if cache enabled
	   	$cache = function_exists('apc_store');
	   	// check if instance exists already
	   	if (!(self::$_instance instanceof self)) {
	   		self::$_instance = new self();
	   		if ($cache) { // store into cache if available
	   			apc_store(Nokia_Api_UserProfile::$apcKey, self::$_instance);
	   		}
	   	}
	   	// return instance from cache if available
	   	return $cache ? apc_fetch(Nokia_Api_UserProfile::$apcKey) : self::$_instance;
	   }

	   /**
	    * Set configuration array.
	    * @see trunk/library/Nokia/Sso/Nokia_Sso_Api::setConfig()
	    */
	   public function setConfig(array $config)
	   {
	   	return parent::setConfig(array_merge($this->_configApi, $config));
	   }

	   /**
	    * Set tokenInfo as OAuthToken object
	    */
	   public function setTokeninfo($token)
	   {
	   	return parent::getTokenInfo($token);
	   }

	   /**
	    * API to retrieve user account information summary.
	    * access public
	    * @param  $accountId
	    * @return UserInfo Array
	    */

	   public function fetchUserInfo($accountId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$responseXml = $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserInfo'])
	   	);

	   	$unicode_email = $this->idna_toUnicode($responseXml->info->email);
	    $responseXml->info->email = $unicode_email;
	    return $responseXml;
	   }

	   /**
	    * API to retrieve complete user profile.
	    * @access public
	    * @param  $accountId
	    * @return UserProfile Array
	    */
	   public function fetchUserProfile($accountId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$responseXml = $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserProfile'])
	   	);

	   	$unicode_email = $this->idna_toUnicode($responseXml->profile->email);
	    $responseXml->profile->email = $unicode_email;
	    return $responseXml;
	   }

	   /** API to Update user profile
	    * @access public
	    * @param String $accountId
	    * @param Array $data of username,sendVerification,userData
	    * @throws Exception
	    * @return xml of user profile data
	    */
	   public function updateUserProfile($accountId, array $data)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<profileUpdateRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<username></username>
<userData></userData>
<sendVerification></sendVerification>
</profileUpdateRequest>
XML;

	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$xml = simplexml_load_string($xmlString);
	   	if(!empty($data['username']))
	   	$xml->username = $data['username'];

	   	if(!empty($data['sendVerification']))
	   	$xml->sendVerification = $data['sendVerification'];


	   	if(!empty($data['userData']))
	   	{
	   		if(is_array($data['userData']))
	   		{
	   			foreach ($data['userData'] as $key => $value)
	   			{
	   				if($key == 'password'){
	   				// Convert password value to base64 string
	   				$value = (string) base64_encode($data['userData'][$key]);
	   				}
	   				$xml->userData->addChild($key, $value);
	   			}
	   		}
	   	}

	   	if(!empty($data['userData']['email'])){
		   	$ascii_email = $this->idna_toAscii($xml->userData->email);
		   	$xml->userData->email = $ascii_email;
	   	}

	   	if(empty($data['request']['ip']))
	   	$ip = $_SERVER['REMOTE_ADDR'];
	   	else
	   	$ip = $data['request']['ip'];

	   	if(empty($data['request']['userAgent']))
	   	$userAgent = $_SERVER['HTTP_USER_AGENT'];
	   	else
	   	$userAgent = $data['request']['userAgent'];

	   	$userProfileXml = $this->requestProfileUpdate($accountId, $xml,
	   	$ip, $userAgent);

	   	//return user profile
	   	$unicode_email = $this->idna_toUnicode($userProfileXml->userProfile->email);
	   	$userProfileXml->userProfile->email = $unicode_email;
	   	return $userProfileXml;
	   }

	   /**
	    * API to retrieve user additional contact information from the server.
	    * @access public
	    * @param string $accountId
	    * @return xml of user contacts
	    */

	   public function fetchContacts($accountId)
	   {
	   	if(!empty($accountId))
	   	$fetchContactsXml = $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserContact'])
	   	);
	   	else
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	// return user contacts
	   	$unicode_email = $this->idna_toUnicode($fetchContactsXml->contacts->emailContactOutput->emailAddress);
	   	$fetchContactsXml->contacts->emailContactOutput->emailAddress = $unicode_email;
	   	return $fetchContactsXml;
	   }


	   /**
	    * API to update user contact information.
	    * @access Public
	    * @param String $accountId
	    * @param Array $emailContacts as emailAddress and preferred
	    * @param Array $mobileContacts as mobileNumber and preferred
	    * @return Simple XML object
	    */
	   public function updateUserContacts($accountId,  array $mobileContacts = null ,array $emailContacts = null)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<contactsUpdateRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<mobileContacts></mobileContacts>
<emailContacts></emailContacts>
</contactsUpdateRequest>
XML;
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$xml = simplexml_load_string($xmlString);

	   	if(!empty($mobileContacts))
	   	{
	   		foreach($mobileContacts as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$mobileContactsArrayNode = $xml->mobileContacts->addChild('mobileContact');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$mobileContactsArrayNode->addChild($k,$v);
	   			}

	   		}

	   		if(!is_array(current($mobileContacts)))
	   		$mobileContactNode = $xml->mobileContacts->addChild('mobileContact');
	   		if(!empty($mobileContacts['mobileNumber']))
	   		$mobileContactNode->addChild('mobileNumber',$mobileContacts['mobileNumber']);
	   		if(!empty($mobileContacts['preferred']))
	   		$mobileContactNode->addChild('preferred',$mobileContacts['preferred']);

	   	}

	   	if(!empty($emailContacts))
	   	{
	   		foreach($emailContacts as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$emailContactsArrayNode = $xml->emailContacts->addChild('emailContact');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$emailContactsArrayNode->addChild($k,$this->idna_toAscii($v));
	   			}

	   		}
	   		if(!is_array(current($emailContacts)))
	   		$emailContactsNode = $xml->emailContacts->addChild('emailContact');
	   		if(!empty($emailContacts['emailAddress']))
	   		$emailContactsNode->addChild('emailAddress',$this->idna_toAscii($emailContacts['emailAddress']));
	   		if(!empty($emailContacts['preferred']))
	   		$emailContactsNode->addChild('preferred',$emailContacts['preferred']);

	   	}
	   	$responseXml = $this->requestUpdateContact($accountId, $xml);
	   	$unicode_email = $this->idna_toUnicode($responseXml->contacts->emailContactOutput->emailAddress);
	   	$responseXml->contacts->emailContactOutput->emailAddress = $unicode_email;
	   	return $responseXml;
	   }

	   /**
	    * API to retrieve marketing consent for service information.
	    * @access public
	    * @return XML Marketing Consent Details
	    * @param string $accountId
	    * @param string $serviceId
	    */

	   public function fetchMarketingConsent($accountId, $serviceId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	if(empty($serviceId))
	   	throw new Exception("Invalid Message Format::Service Id Null");

	   	$fetchMarketingConsentXml = $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] .str_replace(array('%s', '%t'),
	   	array($accountId, $serviceId),
	   	$this->_config['ssoUrlUserMarketingConsent']
	   	)
	   	);
	   	// return user contacts
	   	return $fetchMarketingConsentXml;
	   }

	   /**
	    * API to Update marketing consent for services
	    * @access public
	    * @param String $accountId
	    * @param String $serviceId
	    * @param Array $data as marketingConsent
	    */

	   public function updateMarketingConsent($accountId, $serviceId, array $data)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<marketingConsentUpdateRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<marketingConsent></marketingConsent>
</marketingConsentUpdateRequest>
XML;
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	if(empty($serviceId))
	   	throw new Exception("Invalid Message Format::Service Id Null");

	   	$xml = simplexml_load_string($xmlString);
	   	if(!empty($data['marketingConsent']))
	   	{
	   		if(is_array($data['marketingConsent']))
	   		{
	   			foreach ($data['marketingConsent'] as $key => $value)
	   			{
	   				$xml->marketingConsent->addChild($key, $value);
	   			}
	   		}

	   	}
	   	return $this->requestMarketingConsentUpdate($accountId, $serviceId, $xml);
	   }

	   /**
	    * API to get consent query variant information.
	    * @access public
	    * @return XML ConsentQueryVariant
	    * @param String $country
	    */
	   public function fetchConsentQueryVariant($country)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<consentQueryVariantRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<country></country>
</consentQueryVariantRequest>
XML;
	   	$xml = simplexml_load_string($xmlString);

	   	if(!empty($country))
	   	$xml->country = $country;
	   	else
	   	throw new Exception("Invalid Message Format::Country Code Required");

	   	$ConsentQueryVariantXml = $this->requestConsentQueryVariant($country, $xml);

	   	return $ConsentQueryVariantXml;
	   }
	   /**
	    * API to retrieve user terms acceptance information.
	    * @access public
	    * @return XML UserTermsAcceptanceInfo
	    * @param string $accountId
	    */

	   public function fetchUserTermsAcceptanceInfo($accountId)
	   {
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserTermsAcceptanceInfo'])
	   	);
	   }

	   /**
	    * API to update Terms Acceptance Info
	    * @access public
	    * @param string $accountId
	    * @param Array $data as termsData
	    */

	   public function updateTermsAcceptance($accountId, array $data)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<termsUpdateRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
</termsUpdateRequest>
XML;
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$xml = simplexml_load_string($xmlString);

	   	foreach ($data as $key => $value) {
	   		$xml->addChild($key, $value);
	   	}
	   	return $this->requestTermsAcceptanceUpdate($accountId, $xml);
	   }

	   /**
	    * API to send email and mobile verification message.
	    * This is the first step for contact (email) verification process.
	    * @access public
	    * @param string $accountId
	    * @param Array $data as sendPlainToken, messageBody, returnUrl, mobileNumber, emailAddress
	    */
	   public function sendEmailMobileVerification($accountId, array $data)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<contactsSendVerificationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
</contactsSendVerificationRequest>
XML;
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$xml = simplexml_load_string($xmlString);

	   	if(!empty($data['sendPlainToken']))
	   	{
	   		$xml->addChild('sendPlainToken');
	   		$xml->sendPlainToken = $data['sendPlainToken'];
	   	}
	   	elseif(!empty($data['messageBody']))
	   	{
	   		$xml->addChild('messageBody');
	   		$xml->messageBody = $data['messageBody'];
	   	}
	   	elseif(!empty($data['returnUrl']))
	   	{
	   		$xml->addChild('returnUrl');
	   		$xml->returnUrl = $data['returnUrl'];
	   	}
	   	else
	   	{
	   		throw new Exception("Invalid Message Format:: Parameters Null");
	   	}
	   	if(!empty($data['mobileNumber']))
	   	{
	   		if(is_array($data['mobileNumber']))
	   		{
	   			foreach ($data['mobileNumber'] as $value)
	   			{
	   				$xml->addChild('mobileNumber',$value);
	   			}
	   		}
	   	}
	   	if(!empty($data['emailAddress']))
	   	{
	   		if(is_array($data['emailAddress']))
	   		{
	   			foreach ($data['emailAddress'] as $value)
	   			{
	   				$xml->addChild('emailAddress',$this->idna_toAscii($value));
	   			}
	   		}
	   	}
	   	return $this->requestEmailMobileVerification($accountId, $xml);
	   }

	   /**
	    * API to update existing contacts verification status.
	    * @access public
	    * @param string $accountId
	    * @param Array $mobileContacts as mobileNumber and verified
	    * @param Array $emailContacts as emailAddress and verified
	    */
	   public function updateUserVerificationStatus($accountId, array $mobileContacts = null, array $emailContacts = null)
	   {
	   	$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<contactsVerificationUpdateRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
<mobileContacts></mobileContacts>
<emailContacts></emailContacts>
</contactsVerificationUpdateRequest>
XML;
	   	if(empty($accountId))
	   	throw new Exception("Invalid Message Format::Account Id Null");

	   	$xml = simplexml_load_string($xmlString);

	   	if(!empty($mobileContacts))
	   	{
	   		foreach($mobileContacts as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$mobileContactsArrayNode = $xml->mobileContacts->addChild('mobileContact');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$mobileContactsArrayNode->addChild($k,$v);
	   			}

	   		}

	   		if(!is_array(current($mobileContacts)))
	   		$mobileContactNode = $xml->mobileContacts->addChild('mobileContact');
	   		if(!empty($mobileContacts['mobileNumber']))
	   		$mobileContactNode->addChild('mobileNumber',$mobileContacts['mobileNumber']);
	   		if(!empty($mobileContacts['verified']))
	   		$mobileContactNode->addChild('verified',$mobileContacts['verified']);

	   	}
	   	if(!empty($emailContacts))
	   	{
	   		foreach($emailContacts as $key => $val)
	   		{
	   			if(is_array($val))
	   			{
	   				$emailContactsArrayNode = $xml->emailContacts->addChild('emailContact');
	   				foreach($val as $k=>$v)
	   				if(!empty($v))
	   				$emailContactsArrayNode->addChild($k,$this->idna_ToAscii($v));
	   			}

	   		}
	   		if(!is_array(current($emailContacts)))
	   		$emailContactsNode = $xml->emailContacts->addChild('emailContact');
	   		if(!empty($emailContacts['emailAddress']))
	   		$emailContactsNode->addChild('emailAddress',$this->idna_ToAscii($emailContacts['emailAddress']));
	   		if(!empty($emailContacts['verified']))
	   		$emailContactsNode->addChild('verified',$emailContacts['verified']);

	   	}
	   	return $this->requestUserVerificationStatus($accountId, $xml);
	   }

	   /**
	    * API to verify contact information.
	    * @access public
	    * This is the second step for contact (email/mobile) verification process.
	    * @param string $verificationToken
	    */

	   public function verifyContact($verificationToken)
	   {
	   	if(empty($verificationToken))
	   	throw new Exception("Invalid Message Format::Token Id Null");

	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%t', $verificationToken, $this->_config['ssoUrlVerifyToken'])
	   	);
	   }

	   /**
	    * Request for Update Terms Acceptance
	    * @access private
	    * @param string $accountId
	    * @param string $serviceId
	    * @param SimpleXMLObject $xml
	    */
	   private function requestTermsAcceptanceUpdate($accountId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] .
	   	str_replace('%s', $accountId, $this->_config['ssoUrlUserTermsAcceptanceInfo']),
        'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request for userProfile request
	    * @access private
	    * @param string $accountId
	    * @param SimpleXMLObject $xml
	    * @param string $ip Original requestors IP address
	    * @param string $userAgent Original requestors user agent string.
	    */

	   private function requestProfileUpdate($accountId, $xml, $ip, $userAgent)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserProfile']),
		'PUT',
	   	array( //array of parameters (post data)
                'XMLContent' => $xml->asXML(),
	   	),
	   	array( //array of extra headers (original user)
                'X-Nokia-Original-User-IP: ' . $ip,
                'X-Nokia-Original-User-Agent: ' . $userAgent
	   	)
	   	);
	   }

	   /**
	    * Request for Update marketing consent
	    * @access private
	    * @param string $accountId
	    * @param string $serviceId
	    * @param SimpleXMLObject $xml
	    */

	   private function requestMarketingConsentUpdate($accountId, $serviceId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] .
	   	str_replace(array('%s', '%t'),array($accountId, $serviceId),$this->_config['ssoUrlUserMarketingConsent']
	   	),
        'PUT',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request for Email Mobile Verification
	    * @access private
	    * @param string $accountId
	    * @param SimpleXMLObject $xml
	    */

	   private function requestEmailMobileVerification($accountId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlSendEmailMobileVerfication']),
            'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request for User Verification Status
	    * @access private
	    * @param string $accountId
	    * @param SimpleXMLObject $xml
	    */

	   private function requestUserVerificationStatus($accountId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlContactsverification']),
            'POST',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request for Update Contact Status
	    * @access private
	    * @param string $accountId
	    * @param SimpleXMLObject $xml
	    */

	   private function requestUpdateContact($accountId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUpdateUserContact']),
            'PUT',
	   	array(
                'XMLContent' => $xml->asXml()
	   	)
	   	);
	   }

	   /**
	    * Request for ConsentQueryVariant
	    * @access private
	    * @param string $countryId
	    * @param SimpleXMLObject $xml
	    */

	   private function requestConsentQueryVariant($countryId, $xml)
	   {
	   	return $this->signedRequest(
	   	$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlQueryConsentVariant'],
			'POST',
	   	array( //array of parameters (post data)
                'XMLContent' => $xml->asXML()
	   	)
	   	);
	   }

}
?>