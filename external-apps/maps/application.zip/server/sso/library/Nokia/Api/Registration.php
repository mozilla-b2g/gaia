<?php
/** Nokia_Sso_Api */
require_once 'Nokia/Sso/Api.php';

/**
 * NoA server PHP SDK - This class contains all APIs which are
 * needed to do registration.
 */
class Nokia_Api_Registration extends Nokia_Sso_Api
{
	private $_configExtra = array(
        'ssoUrlCaptchaCreation'      => '/rest/1.0/captchas',
        'ssoUrlCaptchaVerification'  => '/rest/1.0/captchas/%s/verify',
        'ssoUrlApiRegistration'      => '/rest/1.0/accounts',
		'ssoUrlUserNameAvailability' => '/rest/1.0/availability/%s'
		);

		/**
		 * Key used at APC caching (if available)
		 * @var string $apcKey
		 */
		static public $apcKey = "NokiaApiRegistrationSingleton";

		/**
		 * Singleton instance of Nokia_Api_Registration
		 * @var Nokia_Api_Registration $_instance
		 */
		static private $_instance;
		/**
		 * Get singleton intance
		 * @return Nokia_Api_Registration
		 */
		static public function getInstance() {
			// check if cache enabled
			$cache = function_exists('apc_store');
			// check if instance exists already
			if (!(self::$_instance instanceof self)) {
				self::$_instance = new self();
				if ($cache) { // store into cache if available
					apc_store(Nokia_Api_Registration::$apcKey, self::$_instance);
				}
			}
			// return instance from cache if available
			return $cache ? apc_fetch(Nokia_Api_Registration::$apcKey) : self::$_instance;
		}

		/**
		 * Set configuration array.
		 * @see trunk/library/Nokia/Sso/Nokia_Sso_Api::setConfig()
		 */
		public function setConfig(array $config) {
			return parent::setConfig(array_merge($this->_configExtra, $config));
		}

		/**
		 * API to retrieve Catcha information.
		 * @access public
		 * @return Simple XML Object
		 * @param string $width
		 * @param string $height
		 * @param string $lang
		 */

		public function getCaptcha($width = 0, $height = 0, $lang = 'en') {
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<captchaCreationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
    <width></width>
    <height></height>
    <language></language>
</captchaCreationRequest>
XML;
			$xml = simplexml_load_string($xmlString);
			if(!empty($width))
			$xml->width = $width;
			else
			throw new Exception("Invalid Message Format::Width is required");

			if(!empty($height))
			$xml->height = $height;
			else
			throw new Exception("Invalid Message Format::Height is required");

			if(!empty($lang))
			$xml->language = $lang;

			$responseXml = $this->requestCaptcha($xml);
			return $responseXml;
		}

		/**
		 * API to verify that $imageText is valid for $captchaId
		 * Access public
		 * @param string $captchaId
		 * @param string $imageText
		 * @throws Exception
		 */

		public function verifyCaptcha($captchaId, $imageText) {
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8" ?>
<captchaVerificationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
    <captchaId></captchaId>
    <imageText></imageText>
</captchaVerificationRequest>
XML;
			$xml = simplexml_load_string($xmlString);

			if(!empty($captchaId))
			$xml->captchaId = $captchaId;
			else
			throw new Exception("Invalid Message Format::Captcha Id required");

			if(!empty($imageText))
			$xml->imageText = $imageText;
			else
			throw new Exception("Invalid Message Format::Image Text required");

			$responseXml = $this->requestVerifyCaptcha($captchaId, $xml);
			return true;
		}

		/**
		 * API to register new user into Nokia Account
		 * @access public
		 * @return Simple XML Object
		 * @param Array $data as captchaId,imageText,username,userData,guardianToken,marketingConsent,phoneActivation,campaignId,ip,userAgent
		 */

		public function doRegister(array $data = null) {

			//Either captcha details or service tag is needed for registration XML. SDK uses captcha by default.
			//For servicetag, remove captchaId and imageText from below XML and add serviceTag.
			$xmlString = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<registrationRequest xmlns="http://account.nokia.com/schemas/rest/v1_0">
</registrationRequest>
XML;
			$xml = simplexml_load_string($xmlString);

			if(!empty($data['captchaId']))
			{
				$xml->addChild('captchaId');
				$xml->captchaId = $data['captchaId'];
			}

			if(!empty($data['imageText']))
			{
				$xml->addChild('imageText');
				$xml->imageText = $data['imageText'];
			}

			if(!empty($data['username']))
			{
				$xml->addChild('username');
				$xml->username = $data['username'];
			}

			if(!empty($data['serviceTag']))
			{
				$xml->addChild('serviceTag');
				$xml->serviceTag = $data['serviceTag'];
			}

			if(!empty($data['userData']))
			{
				if(is_array($data['userData']))
				{
					$xml->addChild('userData');
					$userDataArrayNode = $xml->userData;
					foreach ($data['userData'] as $key => $value)
					{
						if($key == 'password'){
							// Convert password value to base64 string
							$value = (string) base64_encode($data['userData'][$key]);
						}
						if($key == 'email')
						{
							$value =  $this->idna_toAscii($data['userData']['email']);
						}
						$userDataArrayNode->addChild($key, $value);
					}
				}
			}

			if(!empty($data['guardianToken']))
			{
				$xml->addChild('guardianToken');
				$xml->guardianToken = $data['guardianToken'];
			}

			if(!empty($data['sendVerification']))
			{
				$xml->addChild('sendVerification');
				$xml->sendVerification = $data['sendVerification'];
			}

			if(!empty($data['marketingConsent']))
			{
				if(is_array($data['marketingConsent']))
				{
					foreach($data['marketingConsent'] as $key => $val)
					{
						if(is_array($val))
						{
							$marketingConsentArrayNode = $xml->addChild('marketingConsent');
							foreach($val as $k=>$v)
							$marketingConsentArrayNode->addChild($k,$v);
						}
					}

					if(!empty($data['marketingConsent']['email']) || !empty($data['marketingConsent']['mobile'])  || !empty($data['marketingConsent']['serviceId']))
					{
						$marketingConsentNode = $xml->addChild('marketingConsent');
						$marketingConsentNode->addChild('email',$data['marketingConsent']['email']);
						$marketingConsentNode->addChild('mobile',$data['marketingConsent']['mobile']);
						$marketingConsentNode->addChild('serviceId',$data['marketingConsent']['serviceId']);
					}
				}
			}

			if(!empty($data['phoneActivation']))
			{
				$xml->addChild('phoneActivation');
				$xml->phoneActivation = $data['phoneActivation'];
			}

			if(!empty($data['campaignId']))
			{
				$xml->addChild('campaignId');
				$xml->campaignId = $data['campaignId'];
			}

			$responseXml = $this->requestRegistration($xml, $data['request']['ip'], $data['request']['userAgent']);
			$unicode_email = $this->idna_toUnicode($responseXml->userInfo->email);
			$responseXml->userInfo->email = $unicode_email;
			return $responseXml;
		}


		/**
		 * API to check username availability.
		 * Access public
		 * @param string $username
		 * @throws Exception
		 */

		public function userNameAvailability($username)
		{
			if(empty($username))
			throw new Exception("Invalid Message Format::UserName required");

			$responseXml = $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $username, $this->_config['ssoUrlUserNameAvailability']));
			if(!empty($responseXml->userNameSuggestions->userNameSuggestion))
			return $responseXml;
			else
			return true;
		}


		/**
		 * Request new account creation.
		 * @param SimpleXMLObject $xml
		 * @param string $ip Original requestors IP address
		 * @param string $userAgent Original requestors user agent string.
		 */
		private function requestRegistration($xml, $ip, $userAgent) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlApiRegistration'], //get url
            'POST', //method
			array( //array of parameters (post data)
                'XMLContent' => $xml->asXML()
			),
			array( //array of extra headers (original user)
                'X-Nokia-Original-User-IP: ' . $ip,
                'X-Nokia-Original-User-Agent: ' . $userAgent
			)
			);
		}

		/**
		 * Request new captcha image from Nokia Account.
		 * @param SimpleXMLObject $xml
		 */

		private function requestCaptcha($xml) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . $this->_config['ssoUrlCaptchaCreation'],
            'POST',
			array(
                'XMLContent' => $xml->asXML()
			)
			);
		}

		/**
		 * Request captcha verification from Nokia Account.
		 * @param string $captchaId
		 * @param SimpleXMLObject $xml
		 */

		private function requestVerifyCaptcha($captchaId, $xml) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $captchaId, $this->_config['ssoUrlCaptchaVerification']),
            'POST',
			array(
                'XMLContent' => $xml->asXML()
			)
			);
		}
}
?>