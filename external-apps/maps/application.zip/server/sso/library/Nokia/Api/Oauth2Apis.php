<?php
/** Nokia_Sso_Api */
require_once 'Nokia/Sso/Api.php';
/** Prptobuf library files */
require_once('Protocolbuf/message/pb_message.php');
require_once('Protocolbuf/pb_proto_Oauth2AccessToken.php');
/**
 * NoA server PHP SDK - This class contains all oAuth 2.0 protocol based API implementation
 * related to token.
 */
class Nokia_Api_Oauth2 extends Nokia_Sso_Api
{
		/**
		 * Key used at APC caching (if available)
		 * @var string $apcKey
		 */
		static public $apcKey = "NokiaApiOauth2Singleton";

		/**
		 * Singleton instance of Nokia_Api
		 * @var Nokia_Api_Oauth2 $_instance
		 */
		static private $_instance;

		/**
		 * Get singleton intance
		 * @return Nokia_Api_Oauth2
		 */
		static public function getInstance()
		{
			// check if cache enabled
			$cache = function_exists('apc_store');
			// check if instance exists already
			if (!(self::$_instance instanceof self)) {
				self::$_instance = new self();
				if ($cache) { // store into cache if available
					apc_store(Nokia_Api_Oauth2::$apcKey, self::$_instance);
				}
			}
			// return instance from cache if available
			return $cache ? apc_fetch(Nokia_Api_Oauth2::$apcKey) : self::$_instance;
		}

		/**
		 * Set configuration array.
		 * @see trunk/library/Nokia/Sso/Nokia_Sso_Api::setConfig()
		 */
		public function setConfig(array $config)
		{
			return parent::setConfig($config);
		}

		/**
		 * API to retrieve access token infor by sending a refresh token.
		 * @access Public
		 * @param string $refreshToken Refresh token
		 * @return access token information
		 */
		public function getAccessTokenFromRefreshToken($refreshToken, $scope = null)
		{
			if(empty($refreshToken))
			throw new Exception("Invalid Message Format::Refresh Token cannot be Null");

			$parameters = array('grant_type' => 'refresh_token',
     					  'client_id' => $this->_config['client_id'],
     					  'refresh_token' => $refreshToken,
						  'client_secret' => $this->_config['client_secret']
     					  );
			if (!empty($scope)) {
				$parameters = array_merge($parameters, array('scope'=> $scope));
			}
          	// get access token info from NoA
			$accessTokenResponse = $this->_requestUrl(
							$this->getUrl($this->_config['ssoBaseUrl'], $this->_config['ssoUrlOauth2AccessToken']),
							null,'POST',$parameters);

			$response = $this->explodeAccessTokenResponse($accessTokenResponse);

			//need to decrypt opaque access token*/
		    list($accessTokenInfo, $accessTokenExtInfo) = $this->decryptOpaqueToken($response['access_token']);

	    	$accountId = bin2hex($accessTokenInfo->accountId());
	    	$formattedAccountId = preg_replace("/^([a-z0-9]{8})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{4})([a-z0-9]{12})$/i", "$1-$2-$3-$4-$5", $accountId);

	    	$refreshToken = isset($response['refresh_token'])?$response['refresh_token']:null;

	    	$accessTokenData = array();
	    	if (!empty($accessTokenInfo))
	    	{
	    		$accessTokenData = array(
				'accesstokenInfo'			=> array(
					'tokenid'				=> (string) bin2hex($accessTokenInfo->id()),
					'accountid'				=> (string) $formattedAccountId,
	    			'validuntil'			=> (string) $accessTokenInfo->validUntil(),
	    			'greetingname'			=> (string) $accessTokenInfo->greetingName(),
	    			'authenticationtype'	=> 'REFRESH_TOKEN',
	    			'creator'				=> (string) bin2hex($accessTokenInfo->creator()),
	    			'originator'			=> (string) bin2hex($accessTokenInfo->originator()),
	    			'token_type'			=> (string) $response['token_type'],
	    			'expires'				=> (string) $response['expires_in'],
	    			'refresh_token'			=> (string) $refreshToken
	    		));
	    	}

	    	if (!empty($accessTokenExtInfo))
	    	{
	    		$accessTokenData['accesstokenExtInfo']	= array(
					'legacy_token'				=> (string) $accessTokenExtInfo->legacyToken(),
	    			'username'					=> (string) $accessTokenExtInfo->userName(),
	    			'compatibilityusername'		=> (string) $accessTokenExtInfo->compatibilityUserName(),
	    			'scope'						=> $this->getScopeValue($accessTokenExtInfo->scope()));
	    	}

		    return $accessTokenData;
		}


		/**
		 * API for a client credential flow- authenticating an individual client application instead of a user.
		 * @access Public
		 * @return encrypted opaque token information
		 */
		public function authenticateClientApp($scope = null)
		{
			$parameters = array('grant_type' => 'client_credentials',
     					  'client_id' => $this->_config['client_id'],
						  'client_secret' => $this->_config['client_secret']
     					  );
			if (!empty($scope)) {
				$parameters = array_merge($parameters, array('scope'=> $scope));
			}

          	// get access token info from NoA
			$accessTokenResponse = $this->_requestUrl(
							$this->getUrl($this->_config['ssoBaseUrl'], $this->_config['ssoUrlOauth2AccessToken']),
							null,'POST',$parameters);

			$response = $this->explodeAccessTokenResponse($accessTokenResponse);

			//need to decrypt opaque access token*/
		    list($accessTokenInfo, $accessTokenExtInfo) = $this->decryptOpaqueToken($response['access_token']);

	    	$accessTokenData = array();
	    	if (!empty($accessTokenInfo))
	    	{
	    		$accessTokenData = array(
				'accesstokenInfo'			=> array(
					'tokenid'				=> (string) bin2hex($accessTokenInfo->id()),
	    			'validuntil'			=> (string) $accessTokenInfo->validUntil(),
	    			'authenticationtype'	=> 'CLIENT_CREDENTIALS',
	    			'creator'				=> (string) bin2hex($accessTokenInfo->creator()),
	    			'originator'			=> (string) bin2hex($accessTokenInfo->originator()),
	    			'token_type'			=> (string) $response['token_type'],
	    			'expires'				=> (string) $response['expires_in']
	    		));
	    	}
			if (!empty($accessTokenExtInfo))
	    	{
	    		$accessTokenData['accesstokenExtInfo']	= array(
					'scope'					=> $this->getScopeValue($accessTokenExtInfo->scope()));
	    	}
	    	return $accessTokenData;
		}


		/**
		 * Method to explode Nokia account server access token response
		 * @param encrypoted Access token string along with other info like bearer and expirytime
		 * @return access token response in form of array|false
		 */
		protected function explodeAccessTokenResponse($accessTokenResponse)
		{
			if (empty($accessTokenResponse))
      			return false;
      		else {
      			$response = explode('&',$accessTokenResponse);

				// prepare parameters as array
				for ($i = 0; $i < count($response); $i++) {
					list($key, $value) = explode("=", $response[$i],2);
					unset($response[$i]);
					$response[$key] = $value;
				}
				return $response;
      		}
		}

}