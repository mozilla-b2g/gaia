<?php

class Nokia_Sso_User
{
    private $xml = null;

    public function __construct($data = null) {
        if ($data) {
            if ($data instanceof SimpleXMLElement) {
                $this->xml = $data;
            }
            if (is_string($data)) {
                // parse xml string
                $this->xml = simplexml_load_string($data);
            }
        }
    }

    private function _get($key) {
        $output = array();
        foreach ($this->xml->$key as $value) {
            array_push($output, $value);
        }
        if (count($output) == 1) {
            return (string) $output[0];
        }
    }


    public function getAccountId() {
        return $this->_get('accountId');
    }

    public function getCoachRowId() {
        return $this->_get('coachRowId');
    }

    public function getUsername() {
        return $this->_get('username');
    }

    public function getMobile() {
        return array(
            'mobile'    => $this->_get('mobile'),
            'verified'  => $this->_get('mobileVerified')
        );
    }

    public function getEmail() {
        return array(
            'email'     => $this->_get('email'),
            'verified'  => $this->_get('emailVerified')
        );
    }

    public function getPasswordQuestion() {
        return $this->_get('passwordQuestion');
    }

    public function getLanguage() {
        return $this->_get('language');
    }

    public function getCountry() {
        return $this->_get('country');
    }

    public function getDateOfBirth() {
        return $this->_get('dateOfBirth');
    }

    public function getFirstName() {
        return $this->_get('firstName');
    }

    public function getLastName() {
        return $this->_get('lastName');
    }

    public function getGender() {
        return $this->_get('gender');
    }

    public function getSecondaryMobiles() {
        $o = array();
        foreach ($this->xml->extensions->secondaryMobiles->secondaryMobile as $mobile) {
            array_push($o, array(
                'mobile'    => (string) $mobile->mobile,
                'verified'  => (string) $mobile->verified === 'true' ? true : false
            ));
        }
        return $o;
    }
    public function getSecondaryEmails() {
        $o = array();
        foreach ($this->xml->extensions->secondaryEmails->secondaryEmail as $email) {
            array_push($o, array(
                'email'    => (string) $email->email,
                'verified'  => (string) $email->verified === 'true' ? true : false
            ));
        }
        return $o;
    }
}