<?php
/** Nokia_Sso_Core */
require_once 'Nokia/Sso/Core.php';

/**
 * Nokia SSO library - API interface
 * This interface is developed for Web API usage.
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Api extends Nokia_Sso_Core
{
	/**
	 * Key used at APC caching (if available)
	 * @var string $apcKey
	 */
	static public $apcKey = "NokiaSsoApiSingleton";

	/**
	 * Singleton instance of Nokia_Sso_Session
	 * @var Nokia_Sso_Session $_instance
	 */
	static private $_instance;

	/**
	 * Get singleton intance
	 * @return Nokia_Sso_Api
	 */
	static public function getInstance() {
		// check if cache enabled
		$cache = function_exists('apc_store');
		// check if instance exists already
		if (!(self::$_instance instanceof self)) {
			self::$_instance = new self();
			if ($cache) { // store into cache if available
				apc_store(Nokia_Sso_Api::$apcKey, self::$_instance);
			}
		}
		// return instance from cache if available
		return $cache ? apc_fetch(Nokia_Sso_Api::$apcKey) : self::$_instance;
	}

	/**
     * Set configuration array.
	 * @see trunk/library/Nokia/Sso/Nokia_Sso_Core::setConfig()
	 */
	public function setConfig(array $config) {
        // enforce cache and session storage configuration
        $config['cacheStorage'] = 'phpsession';
        $config['sessionStorage'] = 'phpsession';
	    return parent::setConfig($config);
	}


	/**
	 * Validate current incoming request
	 * If validated basic user info & token info is stored into $_SESSION for latest use
	 */
	public function authorizeOAuthRequest() {
		// first validate that all needed parameters are in use!
		$params = $this->_checkRequiredParams();
		if ($params !== false) {
			try {
				// first validate timestamp
				$this->validateTimestamp($params['oauth_timestamp']);
				// then validate nonce
				$this->validateNonce($params['oauth_nonce']);

				// then get token info (secret)
				if (isset($params['oauth_token']))
				$tokenInfo = $this->getTokenInfo($params['oauth_token']);

				// get consumer key information with given key
			    $consumerInfo = $this->_getConsumerWithKey($params['oauth_consumer_key']);
				// construct consumer object
				$consumer = new OAuthConsumer($consumerInfo['key'], $consumerInfo['secret']);
				// get token information if needed to verify request
				$token = ($consumerInfo['trusted'] !== true) ? $this->getToken() : new OAuthToken("", "");

				// check if incoming signature is valid
				if ($this->validateOAuthRequest($params['oauth_signature'], $consumer, $token)) {
					// all ok - request is authorized
					if (isset($tokenInfo))
						$_SESSION = $tokenInfo;
				} else {
					throw new Exception('Unauthorized', 401);
				}

			} catch (Exception $e) {
			    // return error
				unset($_SESSION);
				$code = $e->getCode();
				if ($code == 400) {
				    $this->returnError(); //do not forward internal error messages
				} else {
    				$this->returnError($code, $e->getMessage());
				}
			}
		} else {
			// request without oauth signing
			unset($_SESSION);
		}
	}

	/**
	 * Send HTTP header for error and stop execution.
	 * @param int $status Optional error header number (HTTP spec)
	 * @param string $message Optional error header message (HTTP spec)
	 */
	public function returnError($status = 400, $message = 'Bad Request') {
        error_log("PHP SSO: API Error Returned - $status - $message");
        // If no headers are sent, send one
        if (!headers_sent()) {
            header("HTTP/1.0 $status $message");
        }
        exit;
	}

	/**
	 * Get token info (either from cache or from sso)
	 * @param array $token Containing 'tokenInfo' and 'userInfo' arrays.
	 */
	public function getTokenInfo($token) {
		$key = 'token_' . $token;
		$data = $this->getCache()->get($key);
		if (!$data) {
			$tokenInfoXml = $this->requestTokenInfo($token);
			$data = array(
				'tokenInfo'		=> array(
					'token'				=> (string) $tokenInfoXml->tokenInfo->token,
					'secret'			=> (string) $tokenInfoXml->tokenInfo->tokenSecret,
					'ttl'				=> (string) $tokenInfoXml->tokenInfo->conditions->ttl,
					'expires'			=> (string) $tokenInfoXml->tokenInfo->conditions->expires
				),
				'userInfo'		=> array(
					'accountId'			=> (string) $tokenInfoXml->userInfo->accountId,
					'username'			=> (string) $tokenInfoXml->userInfo->username,
					'mobile'			=> (string) $tokenInfoXml->userInfo->mobile,
					'email'				=> (string) $tokenInfoXml->userInfo->email,
					'mobileVerified'	=> (string) $tokenInfoXml->userInfo->mobileVerified,
					'emailVerified'		=> (string) $tokenInfoXml->userInfo->emailVerified
				)
			);
			$this->getCache()->set($key, $data, $this->_config['cacheLifetime']);
		}
		if (is_array($data) && array_key_exists('tokenInfo',$data))
		$this->setToken(new OAuthToken($data['tokenInfo']['token'], $data['tokenInfo']['secret']));
		return $data;
	}

	/**
	 * Return users basic profile from $_SESSION
	 */
	public function getUserInfo() {
		if (isset($_SESSION['userInfo'])) {
			return $_SESSION['userInfo'];
		}
	}

	/*
	 * Return users full profile information
	 */
	public function getUserProfile($accountId) {
		$key = 'profile_' . $accountId;
		$data = $this->getCache()->get($key);
		if(!$data) {
			$userProfileXml = $this->requestUserProfile($accountId);
			$data = array(
				'userProfile'	=> array(
					'accountId'		=> (string) $userProfileXml->profile->accountId,
					'username'		=> (string) $userProfileXml->profile->username,
					'firstName'		=> (string) $userProfileXml->profile->firstName,
					'lastName'		=> (string) $userProfileXml->profile->lastName,
					'country'		=> (string) $userProfileXml->profile->country,
					'language'		=> (string) $userProfileXml->profile->language,
					'coachRowId'	=> (string) $userProfileXml->profile->coachRowId,
					'passwordQuestion' => (string) $userProfileXml->profile->passwordQuestion,
					'dateOfBirth'	=> (string) $userProfileXml->profile->dateOfBirth,
					'gender'		=> (string) $userProfileXml->profile->gender,
					'warning'		=> (string) $userProfileXml->profile->warning,
					'mobile'		=> (string) $userProfileXml->profile->mobile,
					'email'			=> (string) $userProfileXml->profile->email,
					'mobileVerified'	=> (string) $userProfileXml->userInfo->mobileVerified,
					'emailVerified'		=> (string) $userProfileXml->userInfo->emailVerified,
					'services'		=> array()
				)
			);
			foreach($userProfileXml->services->service as $service) {
				array_push($data['userProfile']['services'], (string) $service);
			}
			$this->getCache()->set($key, $data);
		}
		return $data;
	}

	/**
	 * Return users additional contacts information
	 */
	public function getUserContacts($accountId) {
		$key = 'contacts_' . $accountId;
		$data = $this->getCache()->get($key);
		if(!$data) {
			$userContactsXml = $this->requestUserContacts($accountId);
			$data = array(
				'userContacts'	=> array(
					'mobile'	=> array(),
					'email'		=> array()
				)
			);
			foreach($userContactsXml->contacts->mobileContactOutput as $mobile) {
				array_push($data['userContacts']['mobile'], array(
					'mobileNumber'	=> (string) $mobile->mobileNumber,
					'preferred'		=> (string) $mobile->preferred,
					'verified'		=> (string) $mobile->verified
					)
				);
			}
			foreach($userContactsXml->contacts->emailContactOutput as $mobile) {
				array_push($data['userContacts']['email'], array(
					'emailAddress'	=> (string) $mobile->mobileNumber,
					'preferred'		=> (string) $mobile->preferred,
					'verified'		=> (string) $mobile->verified
					)
				);
			}
			$this->getCache()->set($key, $data);
		}
		return $data;
	}

	/**
	 * Returns user marketing consent information
	 */
	public function getUserMarketingConsent($accountId, $serviceId) {
		$key = 'marketingconsent_' . $accountId;
		$data = $this->getCache()->get($key);
		if(!$data) {
			$userMarketingConsentXml = $this->requestUserMarketingConsent($accountId, $serviceId);
			$data = array(
				'userMarketingConsent'	=> array(
					'mobile'		=> (string) $userMarketingConsentXml->marketingConsent->email,
					'email'		=> (string) $userMarketingConsentXml->marketingConsent->mobile
				)
			);
			$this->getCache()->set($key, $data);
		}
		return $data;
	}

	/**
	 * Return service description
	 */
	public function getServiceInfo($serviceId) {
		$serviceInfoXml = $this->requestServiceInfo($serviceId);
		$data = array(
			'tosUrl'		=> (string) $serviceInfoXml->tosUrl,
			'serviceUrl'	=> (string) $serviceInfoXml->serviceUrl,
			'extensions'	=> array(
				'serviceSpecificTosUrl' => (string) $serviceInfoXml->extensions->serviceSpecificTosUrl,
				'privacyPolicyUrl'		=> (string) $serviceInfoXml->extensions->privacyPolicyUrl
			)
		);
		return $data;
	}

	/**
	 * Subscribe to the service
	 */
	public function subscribeService($accountId, $serviceId) {
		$this->requestSubscribeService($accountId, $serviceId);
	}

	/**
	 *
	 * Unsubscribe to the service
	 */
	public function unsubscribeService($accountId, $serviceId) {
		$this->requestUnsubscribeService($accountId, $serviceId);
	}



	/**
	 * Check required oauth parameters. First from headers (Authorization) and
	 * if not found then from GET/POST.
	 * @see trunk/library/Nokia/Sso/Nokia_Sso_Core::_checkRequiredParams()
	 * @param array $params
	 */
	protected function _checkRequiredParams(array $params = null) {
		$params = is_array($params) ? $params : Nokia_Sso_Core::$oauthParams;
		$output = $this->_checkParamsFromHeader($params);
		if ($output !== false) //if something goes wrong and output is blank, need to check _checkRequiredParams and urldecode stuff in that function.
			return $output;


		//For trusted clients, chances are very high for not having an oauth token in request,
		//In that case validation should pass.
		$arr = array_intersect(array_keys($_REQUEST), Nokia_Sso_Core::$oauthParams);
		if (!in_array('oauth_token',$arr)) {
			foreach ($params as $k=>$p) {
				if ($p == 'oauth_token')
					unset($params[$k]);
			}
		}
		return parent::_checkRequiredParams($params);
	}

	/**
	 * Check oauth params from header
	 * @param array $params
	 * @param string $headerName
	 * @return array|boolean False if not found.
	 */
	protected function _checkParamsFromHeader(array $params = null, $headerName = 'Authorization') {
		// get all incoming requests
		$headers = getallheaders();
		if (isset($headers[$headerName])) {
			// find header
			$header = explode(',', $headers[$headerName]);
			// prepare parameters as array
			for ($i = 0; $i < count($header); $i++) {
				list($key, $value) = explode("=", $header[$i],2);
				unset($header[$i]);
				$header[$key] = substr($value, 1, -1);
			}
			// loop all required parameters
			$o = array();
			if (!in_array('oauth_token',$header)) {
    			foreach ($params as $k=>$p) {
     				if ($p == 'oauth_token')
      					unset($params[$k]);
    			}
   			}
			foreach ($params as $p) {
				if (isset($header[$p])) {
					$o[$p] = $header[$p];
				} else {
					return false;
				}
			}
			return $o;
		} else {
			return false;
		}
	}

	/**
	 * Get consumer key+secret+trusted information from config
	 * @param string $key
	 * @throws Exception
	 * @return array With keys: (string) 'key', (string) 'secret', (bool) 'trusted'.
	 */
	protected function _getConsumerWithKey($key = null) {
		if ($key === null) {
			throw new Exception('Unauthorized', 401); //no key available - should not happen!
		} elseif (isset($this->_config['keysTrusted'][$key])) {
			$secret = $this->_config['keysTrusted'][$key];
			$trusted = true;
		} elseif (isset($this->_config['keysUntrusted'][$key])) {
			$secret = $this->_config['keysUntrusted'][$key];
			$trusted = false;
		} else {
		    throw new Exception('Unauthorized', 401); //key that does not exist in configs
		}
		return array(
			'key'		=> $key,
			'secret'	=> $secret,
			'trusted'	=> $trusted
		);
	}


	/**
	 * Method to convert a (potentially) non-ASCII email address into IDN Punycode format.
	 * If the string is null, does not contain an '@' character or fails
	 * the IDN conversion, the original string is returned.
	 * @param string the email address to convert
	 * @return the email address in ASCII IDN format, or the string itself if
	 * null or if the string does not contain an '@' character.
	 */
	protected function idna_toAscii($string)
	{
		if (strlen(strstr($string,'@'))>0)
		{
			require_once('IdnaConvert.php');
			$str = explode('@',$string);
			$idn = new idna_convert();
			$encoded = $idn->encode(stripslashes($str[1]));
			return $str[0].'@'.$encoded;

		}
		else
		return $string;
	}

   /**
	 * Method to convert an email address from IDN Punycode format into Unicode format.
	 * If a problem occurs it returns the original string (including returning null on null input).
	 * @param string the email address to convert
	 * @return the email address in Unicode format, or the input string if the
	 * conversion cannot be performed
	 */
	protected  function idna_toUnicode($string)
	{
		if (strlen(strstr($string,'@'))>0)
		{
			require_once('IdnaConvert.php');
			$str = explode('@',$string);
			$idn = new idna_convert();
			$decoded = $idn->decode(stripslashes($str[1]));
			return $str[0].'@'.$decoded;
		}
		else
		return $string;
	}
}