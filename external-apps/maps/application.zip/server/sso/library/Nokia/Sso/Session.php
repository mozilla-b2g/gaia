<?php
/**
 * Nokia SSO library - session handling.
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Session
{
	/**
	 * Key used at APC caching (if available)
	 * @var string $apcKey
	 */
	static public $apcKey = "NokiaSsoSessionSingleton";

	/**
	 * Singleton instance of Nokia_Sso_Session
	 * @var Nokia_Sso_Session $_instance
	 */
	static private $_instance;

	private $_name, $_id, $_storage = null;
	private $_config = array();

	/**
	 * Get singleton intance
	 * @return Nokia_Sso_Session
	 */
	static public function getInstance() {
		// check if instance exists already
		if (!(self::$_instance instanceof self)) {
			self::$_instance = new self();
			if (function_exists('apc_store')) { // store into cache if available
				apc_store(Nokia_Sso_Session::$apcKey, self::$_instance);
			}
		}
		// return instance from cache if available
        return function_exists('apc_fetch') ? apc_fetch(Nokia_Sso_Session::$apcKey) : self::$_instance;
	}

	/**
	 * Get current configuration
	 * @param string $key Optional key of the configuration
     * @return string|array
	 */
	public function getConfig($key = null) {
		if ($key) {
			return isset($this->_config[$key]) ? $this->_config[$key] : null;
		} else {
			return $this->_config;
		}

	}

	/**
	  * Set configuration array. See manual for available keys.
	 * @param array $config Assoc array of configuration
	 * @return Nokia_Sso_Session
	 */
	public function setConfig(array $config) {
		$this->_config = array_merge($this->_config, $config);
		if (isset($this->_config['sessionName'])) {
			$this->setName($this->_config['sessionName']);
		}
		return $this;
	}

	/**
	 * Start session - remember to call setConfig first.
	 * @return Nokia_Sso_Session
	 */
	public function start() {
		$id = $this->_findId();
		$id = ($id === null) ? $this->_generateId() : $id; //generate new id if can't find id
		register_shutdown_function(array($this, 'save'), array('config' => $this->_config, 'id' => $id));
		$this->_startSession($id);
		return $this;
	}

	/**
	 * Save current session - this should be called only automatically!
	 */
	public function save(array $data) {
		if (!isset($data['config']) || !isset($data['id']) ||
			$data['config']['sessionStorage'] == 'phpsession' ||  defined($data['id'])) {
			return;
		}
		if (isset($_SESSION)) {
			$this->setConfig($data['config'])->setId($data['id']);
			$this->_setData($_SESSION);
		}
	}

	/**
	 * Destroy session.
	 * @param string $id
	 * @return Nokia_Sso_Session
	 */
	public function destroy($id = null) {
		if ($id === null) {
			$id = $this->setId($this->_findId())->getId();
		}
		$this->_destroySession($id);
		return $this;
	}

	/**
	 * Get session name string.
	 * @return string
	 */
	public function getName() {
		return $this->_name;
	}

	/**
	 * Set session name string.
	 * @param string $name
	 * @return Nokia_Sso_Session
	 */
	public function setName($name) {
		$this->_name = $name;
		return $this;
	}

	/**
	 * Get current session id.
	 * @return string
	 */
	public function getId() {
		return $this->_id;
	}
	/**
	 * Set current session id.
	 * @param string $id
	 * @return Nokia_Sso_Session
	 */
	public function setId($id) {
		$this->_id = $id;
		return $this;
	}

	/**
	 * Clear current session cookie
	 * @return void
	 */
	public function clearCookie() {
	    return $this->_clearCookie();
	}

	/**
	 * Set session cookie.
	 * @return void
	 */
	public function setCookie() {
	    return $this->_setCookie();
	}

	/**
	 * Check if user has session already started.
	 */
	public function hasSession() {
	    return ($this->_findId() !== null) ? true : false;
	}

	/**
	 * Check if user has session already started.
	 */
	public function validSession() {
	    if ($this->_findId() !== null && strlen($this->_findId()) > 30 && substr($this->_findId(),0,6) !== 'phpnoa_')
	    {
	    	return true;
	    }
	    return false;
	}

	/**
	 * Generate unique session id.
	 * @return string
	 */
	private function _generateId() {
		return uniqid();
	}

	/**
	 * Find session id. Try to find current session id - if not already set into session.
	 * Generates new id if needed.
	 * @return mixed string|null
	 */
	private function _findId() {
		if ($this->_id === null) {
		    if ($this->_config['useSessionCookie'] === true) {
		        $id = isset($_COOKIE[$this->_config['sessionName']]) ? $_COOKIE[$this->_config['sessionName']] : null;
		    } else {
		        $id = isset($_REQUEST[$this->_config['sessionName']]) ? $_REQUEST[$this->_config['sessionName']] : null;
		    }
		} else {
			$id = $this->_id;
		}
		return $id;
	}

	/**
	 * Start session with given id.
	 * @todo Get current data from memcahe
	 * @param string $id Session id.
	 */
	private function _startSession($id) {
		$this->setId($id);
		$_SESSION = $this->_getData();
		if ($this->_config['useSessionCookie'] === true) {
		    $this->_setCookie();
		}
		if (!defined('SID')) {
			define('SID', $this->getName() . '=' . $this->getId());
		}
	}

	/**
	 * Destroy session.
	 * @param string $id Optional ID of session to be deleted.
	 */
	private function _destroySession($id) {
		$this->_getStorage()->delete($id);
		$this->setId(null);
		unset($_SESSION);
        if ($this->_config['useSessionCookie'] === true) {
            $this->_clearCookie();
        }
		define($id, "DELETED");
	}

    /**
     * Set session cookie headers into response
     * @param string $value Optional value. Default is session id.
     */
    private function _setCookie($value = null) {
        $value = $value === null ? $this->getId() : $value;
        setcookie($this->getName(), $value, time()+$this->_config['sessionLifetime'], '/');
    }

    /**
     * Set session cookie to expire with response headers.
     */
    private function _clearCookie() {
        setcookie($this->getName(), $this->getId(), time()-$this->_config['sessionLifetime'], '/');
    }

	/**
	 * Get session data from storage.
	 * @return array
	 */
	private function _getData() {
		$data = $this->_getStorage()->get($this->_id);
		return is_array($data) ? $data : array();
	}

	/**
	 * Set session $data into storage.
	 * @param array $data
	 */
	private function _setData(array $data) {
		$this->_getStorage()->set($this->_id, $data, $this->_config['sessionLifetime']);
	}

	/**
	 * Get session storage object
	 * @return Nokia_Sso_Storage_Abstract
	 */
	private function _getStorage() {
		if ($this->_storage === null) {
			switch ($this->_config['sessionStorage']) {
				case 'memcache':
					require_once 'Nokia/Sso/Storage/Memcache.php';
					$this->_storage = new Nokia_Sso_Storage_Memcache($this->_config);
				break;

				case 'phpsession':
				default:
					require_once 'Nokia/Sso/Storage/PhpSession.php';
					$this->_storage = new Nokia_Sso_Storage_PhpSession($this->_config);
				break;
			}
		}
		return $this->_storage;
	}
}