<?php
/** Nokia_Sso_Core */
require_once 'Nokia/Sso/Core.php';
/** Nokia_Sso_Session */
require_once 'Nokia/Sso/Session.php';

/**
 * Nokia SSO library - Web site interface which uses OAuth 1.0 protocol
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Web extends Nokia_Sso_Core
{
	/**
	 * Key used at APC caching (if available)
	 * @var string $apcKey
	 */
	static public $apcKey = "NokiaSsoWebSingleton";

	/**
	 * Singleton instance of Nokia_Sso_Session
	 * @var Nokia_Sso_Session $_instance
	 */
	static private $_instance, $_session;

	/**
	 * Web interface specific configuration.
	 */
	private $_defaults = array(
	    'linkLabelLogout'          => 'Logout',
	    'linkLabelLogin'           => 'Login',
	    'linkLabelRegister'        => 'Register',
	    'linkLabelAccount'         => 'Account',
	    'linkAttributesLogout'     => array(),
	    'linkAttributesLogin'      => array(),
	    'linkAttributesRegister'   => array(),
	    'linkAttributesAccount'    => array(),
	    'linkHrefLogout'           => 'logout.php'
	    );

	    /**
	     * Get singleton intance
	     * @return Nokia_Sso_Web
	     */
	    static public function getInstance() {
	    	// check if instance exists already
	    	if (!(self::$_instance instanceof self)) {
	    		self::$_instance = new self();
	    		if (function_exists('apc_store')) { // store into cache if available
	    			apc_store(Nokia_Sso_Web::$apcKey, self::$_instance);
	    		}
	    	}
	    	// return instance from cache if available
	    	return function_exists('apc_fetch') ? apc_fetch(Nokia_Sso_Web::$apcKey) : self::$_instance;
	    }

	    /**
	     * Set configuration array. See manual for available keys.
	     * @param array $config Assoc array of configuration
	     * @return self
	     */
	    public function setConfig(array $config) {
	    	$defaultsKeys = array_keys($this->_defaults); // get web specific keys
	    	$defaultsConfig = array();
	    	foreach ($defaultsKeys as $key) { // loop all web specific keys
	    		if (isset($config[$key])) {
	    			$defaultsConfig[$key] = $config[$key]; // store for later use
	    			unset($config[$key]); // unset from core configs
	    		}
	    	}
	    	$this->_defaults = count($defaultsConfig) ? // new config to set?
	    	array_merge($this->_defaults, $defaultsConfig) : // merge
	    	$this->_defaults; // use old
	    	return parent::setConfig($config); // set core configs
	    }

	    /**
	     * Validate request after succesfull login and return token information
	     * @return Token Information XML
	     */
		public function getValidTokenInfo() {
			// first validate that all needed parameters are in use!
			$params = $this->_checkRequiredParams();

			if ($params === false) {
				return null;
			}

			// validate timestamp
			$this->validateTimestamp($params['oauth_timestamp']);

			// validate nonce
			$this->validateNonce($params['oauth_nonce']);

			// request token info
			$tokenInfoXml = $this->requestTokenInfo($params['oauth_token']);

			// create user token object with token+secret
			$this->setToken(new OAuthToken($params['oauth_token'], (string) $tokenInfoXml->tokenInfo->tokenSecret));

			// check if incoming signature is valid
			if ($this->validateOAuthRequest($params['oauth_signature']))
				return $tokenInfoXml;

		}

	    /**
	     * start a session if request is validated after login
	     * @param boolean $fetchUserProfile Set this true if you want to get full user profile from SSO
	     * @return Nokia_Sso_Web
	     */
	    public function createSession($fetchUserProfile = false,
	    $fetchUserContacts = false, $fetchUserMarketing = false) {
	    	//get token information if request validated
	    	$tokenInfoXml = $this->getValidTokenInfo();
	    	if (!empty($tokenInfoXml))
	    	{
	    		//login success
	    		$sessionData = array(
				'tokenInfo'			=> array(
					'token'				=> (string) $tokenInfoXml->tokenInfo->token,
					'secret'			=> (string) $tokenInfoXml->tokenInfo->tokenSecret,
					'ttl'				=> (string) $tokenInfoXml->tokenInfo->conditions->ttl,
					'expires'			=> (string) $tokenInfoXml->tokenInfo->conditions->expires
	    		),
				'userInfo'			=> array(
					'accountId'			=> (string) $tokenInfoXml->userInfo->accountId,
					'username'			=> (string) $tokenInfoXml->userInfo->username,
					'mobile'			=> (string) $tokenInfoXml->userInfo->mobile,
					'email'				=> (string) $tokenInfoXml->userInfo->email,
					'mobileVerified'	=> (string) $tokenInfoXml->userInfo->mobileVerified,
					'emailVerified'		=> (string) $tokenInfoXml->userInfo->emailVerified
	    		),
				'services'          => array()
	    		);

	    		// need to fetch user profile?
	    		if ($fetchUserProfile === true) {
	    			$userInfoXml = $this->requestUserProfile((string) $tokenInfoXml->userInfo->accountId);
	    			$userInfo = array();
	    			$fields = array('accountId','coachRowId','username','mobile','email','mobileVerified','emailVerified',
					'passwordQuestion','language','country','dateOfBirth','firstName','lastName','gender');

	    			foreach ($fields as $f) {
	    				$userInfo[$f] = (string) $userInfoXml->profile->$f;
	    			}
	    			$userInfo['accountType'] = (string) $userInfoXml->profile->extensions->accountType;
	    			$userInfo['compatibilityUserName'] = (string) $userInfoXml->profile->extensions->userProfileExtensions->compatibilityUserName;

	    			$services = (array) $userInfoXml->services;
	    			foreach ($services['service'] as $value) {
	    				$sessionData['services'][$value] = true;
	    			}
	    			$sessionData['userInfo'] = array_merge($sessionData['userInfo'], $userInfo);
	    		}

	    		// need to fetch user addition contacts?
	    		if ($fetchUserContacts === true) {
	    			$userInfoXml = $this->requestUserContacts((string) $tokenInfoXml->userInfo->accountId);
	    			$userContacts = array(
					'mobileContactOutput' => array(),
					'emailContactOutput' => array()
	    			);
	    			foreach ($userInfoXml->contacts->mobileContactOutput as $c) {
	    				array_push(
	    				$userContacts['mobileContactOutput'],
	    				array(
							'mobileNumber' 	=> (string) $c->mobileNumber,
							'preferred'		=> (string) $c->preferred,
							'verified'		=> (string) $c->verified
	    				));
	    			}
	    			foreach ($userInfoXml->contacts->emailContactOutput as $c) {
	    				array_push(
	    				$userContacts['emailContactOutput'],
	    				array(
							'emailAddress' 	=> (string) $c->emailAddress,
							'preferred'		=> (string) $c->preferred,
							'verified'		=> (string) $c->verified
	    				));
	    			}
	    			$sessionData['userContacts'] = $userContacts;
	    		}

	    		// need to fetch user marketing profile?
	    		if ($fetchUserMarketing === true) {
	    			$userInfoXml = $this->requestUserMarketingConsent((string) $tokenInfoXml->userInfo->accountId);
	    			$userMarketing = array(
					'email'		=> (string) $userInfoXml->marketingConsent->email,
					'mobile'	=> (string) $userInfoXml->marketingConsent->mobile
	    			);
	    			$sessionData['userMarketingConsent'] = $userMarketing;
	    		}

	    		// create cookie before starting session!
	    		$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
	    		$session->setCookie();

	    		// start session
	    		$this->startSession((string) $tokenInfoXml->tokenInfo->token, false);

	    		// populate session with data
	    		$_SESSION = array_merge($_SESSION, $sessionData);

	    		// remember to set NOALastLogin cookie in place
	    		$this->setNoaLastLoginCookie();

	    		// everything is done - go get some coffee!
	    	}
	    	return $this;
	    }

	    /**
	     * Start session. Used in the same way as 'session_start()'.
	     * @return Nokia_Sso_Web
	     */
	    public function startSession($id = null, $checkLastLoginCookie = true)
	    {
	    	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);

	    	//check NoALastLogin cookie
	    	if ($checkLastLoginCookie)
	    	isset($_COOKIE['NOALastLogin'])?$checkLastLoginCookie = true:$checkLastLoginCookie = false;

	    	if ($id !== null) {
	    		$session->setId($id);
	    	}
	    	$session->start();

	    	// user not having valid session and NoALastLogin cookie present? -> joinsso
	    	$params = $this->_checkRequiredParams();
	    	if (!isset($_SESSION['tokenInfo']) && $checkLastLoginCookie && $params === false && !isset($_GET['ns']))
	    	{
	    		$this->_redirectJoinSso(false);
	    	}

	    	if(isset($_SESSION['tokenInfo'])) {
	    		// detect if need for token refresh
	    		if (strtotime(gmdate("Y-m-d\TH:i:s\Z")) > (strtotime($_SESSION['tokenInfo']['expires'])-$this->_config['tokenRefreshThreshold'])) {
	    			$this->setToken(new OAuthToken(
	    			$_SESSION['tokenInfo']['token'],
	    			$_SESSION['tokenInfo']['secret'])
	    			);
	    			$tokenInfoXml = $this->requestTokenRefresh($_SESSION['tokenInfo']['token'],$_SESSION['tokenInfo']['secret']);
	    			$_SESSION['tokenInfo'] = array(
                    'token'             => (string) $tokenInfoXml->tokenInfo->token,
                    'secret'            => (string) $tokenInfoXml->tokenInfo->tokenSecret,
                    'ttl'               => (string) $tokenInfoXml->tokenInfo->conditions->ttl,
                    'expires'           => (string) $tokenInfoXml->tokenInfo->conditions->expires
	    			);
	    		}
	    	}
	    	return $this;
	    }

	    /**
	     * End session and redirect user to url defined in session.
	     */
	    public function endSession()
	    {
	    	// get existing session
	    	$this->startSession();

	    	// destroy session
	    	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
	    	$session->destroy();

	    	// clear NOALastLogin cookie too!
	    	$this->setNoaLastLoginCookie(
		    array_merge(
		    $this->getNoaLastLoginCookieData(), //get basic data
		    array('expires' => time() - 60*60) //replace the expiry time to the past (delete)
		    )
		    );

		    // redirect to sso to clear session globally from ovi
		    $header = "Location: " . $this->_config['ssoBaseUrl'] . $this->_config['ssoUrlLogout'] .
            "?returnurl=" . $this->_config['baseUrl'] . $this->_config['logoutDoneUrl'];
		    error_log("header: $header");
		    header($header);
	    }

	    /**
	     * Handle logout notification from SSO (clears users sessions based on incoming XML)
	     * @return void
	     */
	    public function handleNotificationLogout()
	    {
	    	// first validate that all needed parameters are in use! oauth_token is not sent!
	    	$params = $this->_checkRequiredParams(array(
            'oauth_consumer_key',
            'oauth_nonce',
            'oauth_signature',
            'oauth_signature_method',
            'oauth_timestamp',
            'oauth_version'
            ));
            if ($params === false) {
            	return;
            }

            // check if incoming signature is valid, set empty token for validation!
            if ($this->validateOAuthRequest($params['oauth_signature'], null, new OAuthToken("", ""))) {
            	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
            	$xmlString = file_get_contents("php://input");
            	$xmlObject = $this->_parseStringToXml($xmlString);
            	foreach ($xmlObject->tokenId as $token) {
            		$session->destroy((string) $token);
            	}
            }
	    }

	    /**
	     * Handle account notification from SSO
	     * @return array Contains 'type' (string) and 'user' (Nokia_Sso_User).
	     */
	    public function handleNotificationAccount()
	    {
	    	// first validate that all needed parameters are in use! oauth_token is not sent!
	    	$params = $this->_checkRequiredParams(array(
            'oauth_consumer_key',
            'oauth_nonce',
            'oauth_signature',
            'oauth_signature_method',
            'oauth_timestamp',
            'oauth_version'
            ));
            if ($params === false) {
            	return;
            }

            // check if incoming signature is valid, set empty token for validation!
            if ($this->validateOAuthRequest($params['oauth_signature'], null, new OAuthToken("", ""))) {
            	$session = Nokia_Sso_Session::getInstance()->setConfig($this->_config);
            	$xmlString = file_get_contents("php://input");
            	$xmlObject = $this->_parseStringToXml($xmlString);
            	// require user class
            	require_once 'Nokia/Sso/User.php';
            	$output = array(
                'type' => (string) $xmlObject->type,
    		    'user' => new Nokia_Sso_User( $xmlObject->account )
            	);
            	return $output;
            }
	    }

	    /**
	     * Print HTML link (<a../a>) into registration page.
	     * @param string $label Text label for link.
	     * @package array $attributes Array of attributes for <a>-tag. Array key = tag name, value = value.
	     */
	    public function printLinkRegister($label = null, $attributes = null)
	    {
	    	return $this->_generateLinkMarkup(
	    	$this->_config['ssoBaseUrl'] .
	    	str_replace(
	    	array('%s', '%t'),
	    	array($this->_config['ssoServiceId'], urlencode($this->_generateJoinSsoUrl())),
	    	$this->_config['ssoUrlRegister']),
	    	$label === null ? $this->_defaults['linkLabelRegister'] : $label,
	    	$attributes === null ? $this->_defaults['linkAttributesRegister'] : $attributes
	    	);
	    }

	    /**
	     * Print HTML link ('<a../a>') into Login or Logout page depending if user is logged in or not.
	     * @param array $data Assoc array containing 'login' and/or 'logout' arrays. There needs to be keys: (string) href, (string) label, (array) attributes.
	     */
	    public function printLinkLoginLogout($data = array())
	    {
	    	if (isset($_SESSION['userInfo'])) {
	    		// user logged in
	    		$data['logout'] = array(
                'href' => isset($data['logout']['href']) ?
	    		$data['logout']['href'] : $this->_defaults['linkHrefLogout'],
                'label' => isset($data['logout']['label']) ?
	    		$data['logout']['label'] : $this->_defaults['linkLabelLogout'],
                'attributes' => isset($data['logout']['attributes']) ?
	    		$data['logout']['attributes'] : $this->_defaults['linkAttributesLogout']
	    		);
	    		return $this->_generateLinkMarkup(
	    		$data['logout']['href'],
	    		$data['logout']['label'],
	    		$data['logout']['attributes']
	    		);
	    	} else {
	    		// user not logged in

	    		$data['login'] = array(
					           'href' => $this->_generateJoinSsoUrl(true),
					           'label' => isset($data['login']['label']) ?
	    		$data['login']['label'] : $this->_defaults['linkLabelLogin'],
					           'attributes' => isset($data['login']['attributes']) ?
	    		$data['login']['attributes'] : $this->_defaults['linkAttributesLogin']
	    		);

	    		return $this->_generateLinkMarkup(
	    		$data['login']['href'],
	    		$data['login']['label'],
	    		$data['login']['attributes']
	    		);
	    	}
	    }

	    /**
	     * Print HTML link (<a../a>) into account page.
	     * @param string $label Text label for link.
	     * @package array $attributes Array of attributes for <a>-tag. Array key = tag name, value = value.
	     */
	    public function printLinkAccount($label = null, $attributes = null)
	    {
	    	// Where to return from Nokia account ?
	    	$myUrl = parse_url($this->_config['baseUrl'], PHP_URL_SCHEME);
	    	$myUrl = $myUrl .'://'. $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

	    	return $this->_generateLinkMarkup(
	    	$this->_config['ssoBaseUrl'] .
	    	str_replace(
	    	array('%s', '%t'),
	    	array($this->_config['ssoServiceId'], $myUrl),
	    	$this->_config['ssoUrlAccount']),
	    	$label === null ? $this->_defaults['linkLabelAccount'] : $label,
	    	$attributes === null ? $this->_defaults['linkAttributesAccount'] : $attributes
	    	);
	    }
	    /**
	     * Generate HTML markup for link. SID attributes are added automatically.
	     * @param string $href
	     * @param string $label
	     * @param array $attributes
	     * @return string HTML <a> tag with given data.
	     */
	    private function _generateLinkMarkup($href, $label, $attributes = array()) {
	    	// put session id as param if needed
	    	if ($this->_config['useSessionCookie'] === false) {
	    		$href .= strpos($href, '?') === false ? // first param?
                '?' . urlencode(SID) :
                '&' . urlencode(SID);
	    	}
	    	$link = '<a href="' . $href . '"';
	    	if (count($attributes)) { // loop attributes if available
	    		foreach ($attributes as $name => $value) {
	    			$link .= ' ' . $name . '="' . $value . '"';
	    		}
	    	}
	    	$link .= '>' . $label . '</a>';
	    	return $link;
	    }

	    /**
	     * Redirect user into SSO portal for 'joinsso' using Location header.
	     * @param boolen $forceLogin Optional param to force login screen.
	     */
	    private function _redirectJoinSso($forceLogin = false) {
	    	$header = "Location: " . $this->_generateJoinSsoUrl($forceLogin);
	    	header($header);
	    }

	    /**
	     * Generate URL that point into SSO server for joinsso use.
	     * If $forceLogin is set then user will see SSO login page.
	     * @param boolen $forceLogin Optional param to force login screen.
	     * @param Omniture Parameters 'c6' as Local Report Suite Id, 'ch' as Channel, 'c23' as Country Language Info
	     */
	    private function _generateJoinSsoUrl($forceLogin = false) {

	    	if (isset($this->_config['loginDoneUrl']) && !empty($this->_config['loginDoneUrl']))
	    	{
	    		$successUrl = $this->_config['loginDoneUrl'];
	    	}
	    	else
	    	{
	    		//redirect back on same request url
	    		$myUrl = parse_url($this->_config['baseUrl'], PHP_URL_SCHEME);
	    		$requestUri = parse_url($_SERVER['REQUEST_URI']);
	    		//encode querystring
	    		$query = isset($requestUri['query']) ? '?'.urlencode($requestUri['query']) : '' ;
	    		$myUrl = $myUrl .'://'. $_SERVER['SERVER_NAME'] . $requestUri['path'] . $query;
	    		$successUrl = str_replace($this->_config['baseUrl'],'', $myUrl);
	    	}

	    	$url = $this->_config['ssoBaseUrl'] . $this->_config['ssoUrlJoinsso'] . '?';

	    	//Array parameters for Query String
	    	$parameters = array("oauth_consumer_key" => $this->_config['ssoServiceKey'],
        		    		"success_url" => $successUrl );

	    	//error url for Nokia Account to redirect if something went wrong!
	    	if (isset($this->_config['errorUrl']) && !empty($this->_config['errorUrl']))
	    	$parameters["error_url"]= $this->_config['errorUrl'];

	    	//Omniture Parameters added to JoinSsoUrl
	    	if(!empty($_REQUEST['c6']))
	    	$parameters['c6']  = $_REQUEST['c6'];

	    	if(!empty($_REQUEST['ch']))
	    	$parameters['ch']  = $_REQUEST['ch'];

	    	if(!empty($_REQUEST['c23']))
	    	$parameters['c23']  = $_REQUEST['c23'];

	    	if ($forceLogin === false) {
	    		//redirect back if login is not foced (hidden)
	    		$myUrl = parse_url($this->_config['baseUrl'], PHP_URL_SCHEME);
	    		$nosessionUri = parse_url($_SERVER['REQUEST_URI']);
	    		$nsquery = isset($nosessionUri['query']) ? '?'.$nosessionUri['query'].'&ns=true' : '?ns=true';
	    		$myUrl = $myUrl .'://'. $_SERVER['SERVER_NAME'] . $nosessionUri['path'] . $nsquery;
	    		$parameters['noSession'] = str_replace($this->_config['baseUrl'],'', $myUrl);
	    	}
	    	//Generate URL-encoded query string
	    	$queryString = http_build_query($parameters);
	    	$idpUrl = $url . $queryString;

	    	error_log('Generated joinsso URL: ' . $idpUrl);
	    	return $idpUrl;

	    }
}
