<?php
/** Nokia_Sso_Storage_Interface */
require_once 'Nokia/Sso/Storage/Interface.php';

/**
 * Nokia SSO library - session handling using memcached backend.
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 */
class Nokia_Sso_Storage_Memcache implements Nokia_Sso_Storage_Interface
{
	/**
	 * Memcache key prefix.
	 * @var string
	 */
	static private $_keyPrefix = 'sessid_';

	/**
	 * Memcache object
	 * @var Memcache
	 */
	private $_memcache = null;
	/**
	 * Constructor
	 * @param array $config
	 */
	public function __construct($config) {
		$serverList = array();
		foreach ($config['memcacheServers'] as $server) {
			$s = explode(':', $server);
			array_push($serverList, array($s[0], intval($s[1])));
		}
		$this->config = $config;
		/*support for Memcache/Memcached extension*/
		if ((class_exists('Memcached')) && ($config['memcachedExtension'] == true)){
			$this->_memcache = new Memcached();
			$this->_memcache->addServers($serverList);
		}
		else if ((class_exists('Memcache')) && ($config['memcachedExtension'] == false)){
			$this->_memcache = new Memcache();
			if(sizeof($config['memcacheServers']) > 1){
				foreach($config['memcacheServers'] as $memServers){
					$memcacheServer = explode(':', $memServers);
					$this->_memcache->addServer($memcacheServer[0], $memcacheServer[1]);
				}
			}else{
				$memcacheServer = explode(':', $config['memcacheServers'][0]);
				$this->_memcache->connect($memcacheServer[0], $memcacheServer[1]);
			}
		}
		else
		throw new Exception("Memcache or Memcached extensions expected",400);
	}
	/*
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::get()
	 */
	public function get($key) {
		return $this->_memcache->get(Nokia_Sso_Storage_Memcache::$_keyPrefix . $key);
	}
	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::set()
	 */
	public function set($key, $value, $lifeTime) {
		if ((class_exists('Memcache')) && ($this->config['memcachedExtension'] == false))
			return $this->_memcache->set(Nokia_Sso_Storage_Memcache::$_keyPrefix . $key, $value,0,$lifeTime);
		else
			return $this->_memcache->set(Nokia_Sso_Storage_Memcache::$_keyPrefix . $key, $value, $lifeTime);
	}
	/**
	 * (non-PHPdoc)
	 * @see trunk/library/Nokia/Sso/Storage/Nokia_Sso_Storage_Abstract::delete()
	 */
	public function delete($key) {
		return $this->_memcache->delete(Nokia_Sso_Storage_Memcache::$_keyPrefix . $key);
	}
}