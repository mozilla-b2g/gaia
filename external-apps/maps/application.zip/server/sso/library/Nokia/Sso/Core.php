<?php
/** OAuth* classes */
require_once 'OAuth.php';
/** Nokia_Sso_Exception */
require_once 'Nokia/Sso/Exception.php';

/**
 * Nokia SSO library - Core functionality
 * @author Tomi Kulmala <tomi.p.kulmala@nokia.com>
 * @abstract
 */
abstract class Nokia_Sso_Core
{
	/**
	 * Singleton instance of Cache implementation
	 */
	private $_cache = null;

	/**
	 * Needed OAuth parameters
	 * @var array $oauthParams
	 */
	static public $oauthParams = array(
		'oauth_consumer_key',
		'oauth_token',
		'oauth_nonce',
		'oauth_signature_method',
		'oauth_signature',
		'oauth_timestamp',
		'oauth_version'
		);

		/**
		 * Configuration settings.
		 * @var array $_config
		 */
		protected $_config = array(

		//common configurations.
		'environment'                   => 'development',
		'sessionName'			        => 'NokiaSessionId',
        'useSessionCookie'              => true,
        'ssoConnectTimeout'             => 1000,
		'httpTimeout'                   => 3000,
//		'httpProxy'				        => '172.16.43.119:8080',
	    'ssoServiceId'                  => 'PHPLiteIT',
		'baseUrl'           			=> 'http://localhost/phplite',
	    'cacheStorage'                  => 'memcache',
		'sessionStorage'		        => 'memcache',
		'memcachedExtension'            =>  false,  // true: If Memcached implelmenetation required, false: If older memcache implementation required.
		'memcacheServers'		        => array('localhost:11211'),
		'sessionLifetime'		        => 10800,
		'timestampThreshold'	        => 900,
        'tokenRefreshThreshold'         => 1800,
		'nonceThreshold'		        => 900,
		'cacheLifetime'					=> 10800,
		'ssoBaseUrl'			        => 'https://efsun.itlase.com',
		'logoutDoneUrl' 				=> '/examples/web/index.php',

		//Below configuration is needed if service application has opted for OAuth 2.0 protocol.
		'client_id'						=> '',
		'client_secret' 				=> '',
		'redirect_uri'				    => '/examples/web-oauth2/login_success.php',
		'embeddedUIUrl'					=> '/examples/web-oauth2/embeddedUILogin.php',
		'ssoUrlOauth2Authorize'			=> '/oauth2/authorize',
		'ssoUrlOauth2AccessToken'		=> '/oauth2/access_token',

		//Below configuration is needed if service has opted for Oauth 1.0 protocol.
		'ssoServiceKey'			        => '',
		'ssoServiceSecret'		        => '',
		'registerDoneUrl'             	=> 'http://dev-php.example.com/',
		'loginDoneUrl'			    	=> 'login_success.php',
		'errorUrl'						=> '/examples/web/index.php',
	    'ssoUrlRegister'                => '/acct/register?serviceId=%s&returnurl=%t',
		'ssoUrlJoinsso'			        => '/restsso/joinsso',
	    'ssoUrlLogin'                   => '/acct/account/index.html?serviceId=%s&returnurl=%t',
	    'ssoUrlAccount'                 => '/acct/account/index.html?serviceId=%s&returnUrl=%t',
		'ssoUrlLogout'			        => '/fed/user/logout',
		'ssoUrlTokenInfo'		        => '/rest/1.0/tokens/%s',
		'ssoUrlUserProfile'		        => '/rest/1.0/accounts/%s/profile',
		'ssoUrlUserContacts'	        => '/rest/1.0/accounts/%s/contacts',
		'ssoUrlUserMarketingConsent'	=> '/rest/1.0/accounts/%s/marketing/%t',
		'ssoUrlServiceInfo'		        => '/rest/1.0/services/%s',
		'ssoUrlServiceSubscription'     => '/rest/1.0/accounts/%s/services/%t',
		'ssoRealm'				        => 'https://account.nokia.com'
		);

		private $_consumerService, $_token = null;
		/**
		 * Scope Map Array
		 * Before making use of scope it should be added in the below array as array index and array value
		 * @var Array $_scopeMap
		 */
		protected $_scopeMap = array(0 => 'password',
									 1 => 'termination');

		/**
		 * Get current configuration
		 * @param string $key Optional key of the configuration
		 * @return string|array
		 */
		public function getConfig($key = null) {
			if ($key) {
				return isset($this->_config[$key]) ? $this->_config[$key] : null;
			} else {
				return $this->_config;
			}

		}

		/**
		 * Set configuration array. Available keys:
		 * 	- 'sessionName' (string) Session name, default: NokiaSessionId
		 * 	- 'ssoBaseUrl' (string) Base URL for all requests, default 'https://nabbi.noklab.com'
		 * 	- 'ssoServiceKey' (string) Consumer key of the service, default null.
		 * 	- 'loginDoneUrl' (string) Relative URI where the user is redirected after login is done at
		 *    SSO backend. Default 'login_success.php'. Remember not to use hostname!
		 *  - 'logoutDoneUrl' (string) Absolute URI where the user is redirected after logout is done
		 *    at SSO backend. Default 'http://www.ovi.com'. Remember to use hostname!
		 * @param array $config Assoc array of configuration
		 * @return self
		 */
		public function setConfig(array $config) {
			// enforce configuration settings when in production environment
			if (isset($config['environment']) && $config['environment'] == 'production') {
				$config['ssoBaseUrl'] = "https://account.nokia.com";
				$config['sessionStorage'] = 'memcache';
			}
			$this->_config = array_merge($this->_config, $config);
			return $this;
		}

		/**
		 * Check that needed oauth parameters are available at request
		 * @param array $params Array of parameter names
		 * @return array|boolean Assoc array of parameters or false if something is missing.
		 */
		protected function _checkRequiredParams(array $params = null)
		{
			$o = array();
			$params = is_array($params) ? $params : Nokia_Sso_Core::$oauthParams;

			$headers = function_exists('getallheaders') ?
			getallheaders() : array();
			if ( isset($headers['Authorization']) ) {
				// handle authoriztion header
				$authParams = OAuthUtil::split_header($headers['Authorization']);
			} else {
				$authParams = $_REQUEST;
			}

			foreach ($params as $p) {
				if (isset($authParams[$p])) {
					$o[$p] = $authParams[$p];
				} else {
					return false;
				}
			}
			return $o;
		}

		/**
		 * Make the actual HTTP request into SSO
		 * @param string $url
		 * @param array $headers
		 * @throws Nokia_Sso_Exception
		 * @return string HTTP response body
		 */
		public function _requestUrl($url, $headers = null, $httpMethod = 'GET', $parameters = null) {

			// initialize curl handler
			$ch = curl_init($url);
			// check if proxy is needed for http requests
			if (isset($this->_config['httpProxy'])) {
				$proxyConfig = explode(':', $this->_config['httpProxy']);
				curl_setopt($ch, CURLOPT_PROXY, $proxyConfig[0]);
				if (isset($proxyConfig[1]))
					curl_setopt($ch, CURLOPT_PROXYPORT, $proxyConfig[1]);

			}

			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // yes - we need the response body
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // ignore SSL certificate
			curl_setopt($ch, CURLOPT_HEADER, 0); // no need for headers
			curl_setopt($ch, CURLOPT_VERBOSE, 0);
			curl_setopt($ch, CURLOPT_FAILONERROR, 0);
			curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $this->_config['ssoConnectTimeout']);
			curl_setopt($ch, CURLOPT_TIMEOUT, $this->_config['httpTimeout']);


			// set headers if available
			if (is_array($headers)) {
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			}

			// set method
			switch ($httpMethod) {
				case 'POST':
				case 'PUT':
				case 'DELETE':
					if($httpMethod==='POST')
						curl_setopt($ch, CURLOPT_POST, 1);
					else
						curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $httpMethod);
					if ($parameters && is_array($parameters)) {
						$fields_string = '';
						foreach ($parameters as $key => $value) {
							$fields_string .= urlencode($key).'='.urlencode($value).'&';
						}
						$fields_string = substr($fields_string, 0, strlen($fields_string)-1);
						curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
						//curl_setopt($ch, CURLOPT_POSTFIELDS, urlencode($key) . '=' . urlencode($value));
					}
					break;
				case 'GET':
				default:
					curl_setopt($ch, CURLOPT_HTTPGET, 1);
					break;
			}
			// execute curl request to get response
			$response = curl_exec($ch);

			// validate response
			if ($response === false) {
				error_log("PHP SSO: curl error #" . curl_errno($ch) . " found: " . curl_error($ch));
				throw new Exception("Error connecting Nokia Account server!", 503);
			} else {
				$responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);	 //get response code from last request
				if (intval(substr($responseCode, 0, 1)) !== 2)  //check if request was succesfull or not?
				{
					if($responseCode == '412')
						return $response;
					else
						throw new Nokia_Sso_Exception($response, $responseCode, $response); // Throws Exceptions
				}
			}
			// close curl handler
			curl_close($ch);
			// return response string
			return $response;
		}

		/**
		 * Get OAuthConsumer object (service)
		 * @return OAuthConsumer
		 */
		protected function getConsumerService() {
			if ($this->_consumerService === null) {
				$this->_consumerService = new OAuthConsumer(
				$this->_config['ssoServiceKey'],
				$this->_config['ssoServiceSecret']
				);
			}
			return $this->_consumerService;
		}

		/**
		 * Set OAuthConsumer object.
		 * @param OAuthConsumer $consumer
		 * @return $this
		 */
		protected function setConsumerService(OAuthConsumer $consumer) {
			$this->_consumerService = $consumer;
			return $this;
		}

		/**
		 * Get OAuthToken object (client)
		 * @return OAuthToken
		 */
		protected function getToken() {
			return $this->_token;
		}

		/**
		 * Set OAuthToken object
		 * @param OAuthToken $token
		 * @return $this
		 */
		protected function setToken(OAuthToken $token) {
			$this->_token = $token;
			return $this;
		}

		/**
		 * Make tokenInfo request into SSO.
		 * @param string $tokenId
		 * @return SimpleXMLElement
		 */
		public function requestTokenInfo($tokenId) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $tokenId, $this->_config['ssoUrlTokenInfo'])
			);
		}

		/**
		 * Make token refresh request into SSO.
		 * @param string $tokenId
		 * @return SimpleXMLElement
		 */
		public function requestTokenRefresh($tokenId,$tokenSecret) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $tokenId, $this->_config['ssoUrlTokenInfo']),
            'PUT'
            );
		}

		/**
		 * Make userProfile request into SSO.
		 * @param string $accountId
		 * @return SimpleXMLElement
		 */
		public function requestUserProfile($accountId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserProfile'])
			);
		}

		/**
		 * Make userProfile request into SSO.
		 * @param string $accountId
		 * @return SimpleXMLElement
		 */
		public function requestUserContacts($accountId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $accountId, $this->_config['ssoUrlUserContacts'])
			);
		}

		/**
		 * Make userMarketingConsent request into SSO.
		 * @param string $accountId
		 * @return SimpleXMLElement
		 */
		public function requestUserMarketingConsent($accountId = null, $serviceId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] .
			str_replace(
			array('%s', '%t'),
			array($accountId, $serviceId),
			$this->_config['ssoUrlUserMarketingConsent']
			)
			);
		}

		/**
		 * Make serviceInfo request into SSO.
		 * @param string $serviceId
		 * @return SimpleXMLElement
		 */
		public function requestServiceInfo($serviceId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] . str_replace('%s', $serviceId, $this->_config['ssoUrlServiceInfo'])
			);
		}

		/**
		 * Make service subscription request into SSO.
		 * @param string $accountId
		 * @param $string $serviceId
		 * @return SimpleXMLElement
		 */
		protected function requestSubscribeService($accountId = null, $serviceId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] .
			str_replace(
			array('%s', '%t'),
			array($accountId, $serviceId),
			$this->_config['ssoUrlServiceSubscription']
			),
			'POST'
			);
		}

		/**
		 * Make service unsubscription request into SSO.
		 * @param string $accountId
		 * @param $string $serviceId
		 * @return SimpleXMLElement
		 */
		protected function requestUnsubscribeService($accountId = null, $serviceId = null) {
			return $this->signedRequest(
			$this->_config['ssoBaseUrl'] .
			str_replace(
			array('%s', '%t'),
			array($accountId, $serviceId),
			$this->_config['ssoUrlServiceSubscription']
			),
			'DELETE'
			);
		}

		/**
		 * Create signed request into given $url.
		 * @param string $url Absolute HTTP url to be called
		 * @param string $method GET|POST
		 * @param array $parameters Optional parameters.
		 * @param array $headers Optional extra headers.
		 */
		protected function signedRequest($url, $method = 'GET', $parameters = null, $headers = array()) {

			// create user info request object
			$request = OAuthRequest::from_consumer_and_token(
			$this->getConsumerService(),
			$this->getToken(),
			$method,
			$url
			);


			if ($parameters && is_array($parameters)) {
				foreach ($parameters as $key => $value) {
					$request->set_parameter($key, $value);
				}
			}

			// sign request with service + token secrets
			$request->sign_request(
			new OAuthSignatureMethod_HMAC_SHA1(),
			$this->getConsumerService(),
			$this->getToken()
			);
			// get user info from sso
			$responseString = $this->_requestUrl(
			$request->get_normalized_http_url(),
			array_merge(array($request->to_header($this->_config['ssoRealm'])), $headers),
			$request->get_normalized_http_method(),
			$parameters
			);


			// parse response xml
			return $this->_parseStringToXml($responseString);
		}

		/**
		 * Validate given $timestamp.
		 * @param $timestamp integer
		 * @throws Exception
		 */
		protected function validateTimestamp($timestamp) {
			$now = time();
			if (abs($now - $timestamp) > $this->_config['timestampThreshold']) {
				throw new Exception("Invalid timestamp", 400);
			}
		}

		/**
		 * Get cache instance
		 * @return Nokia_Sso_Cache
		 */
		protected function getCache() {
			if ($this->_cache === null) {
				require_once 'Nokia/Sso/Cache.php';
				$this->_cache = Nokia_Sso_Cache::getInstance()->setConfig($this->_config);
			}
			return $this->_cache;
		}

		/**
		 * Validate given $nonce
		 * @param string $nonce
		 * @throws Exception
		 */
		protected function validateNonce($nonce) {
			$key = 'nonce' . $nonce;
			$data = $this->getCache()->get($key);
			if ($data) {
				if (is_array($data)) { //this case can occur if storage type is set to phpsession. very less chances but possible.
					foreach($data as $k=>$v) {
						if(strpos($k, "nonce") === 0)
							throw new Exception("Nonce already used!", 400);
					}
				}
				else
					throw new Exception("Nonce already used!", 400);
			} else {
				$this->getCache()->set($key, true, $this->_config['nonceThreshold']);
			}
		}

		/**
		 * Validate current incoming request to have valid signature.
		 * @return boolean True if signature is the same that in request.
		 */
		protected function validateOAuthRequest($signature, $consumer = null, $token = null) {
			// build request object from incoming request
			$loginRequest = OAuthRequest::from_request();
			// build signature with consumer secret + token secret.
			$validSignature = $loginRequest->build_signature(
			new OAuthSignatureMethod_HMAC_SHA1(),
			$consumer === null ? $this->getConsumerService() : $consumer,
			$token === null ? $this->getToken() : $token
			);

			// check if incoming signature is valid
			if ($validSignature == $signature)
			return true;
			else
			throw new Exception("Incoming signature ".$signature." does not match calculated signature ".$validSignature, 400);
		}


		/**
		 * Parse string into XML object.
		 * @param string|null $string Null if invalid xml string
		 * @return SimpleXMLElement
		 */
		protected function _parseStringToXml($string)
		{
			$o = null;
			try {
				$o = simplexml_load_string($string);
			} catch (Exception $e) {}
			return $o;
		}

		/**
		 * Set NOALastLogin cookie in place
		 * @param array $data with keys: name, value, expires, path, domain. If none given getNoaLastLoginCookieData() is called.
		 * @return bool
		 */
		protected function setNoaLastLoginCookie(array $data = null)
		{
			$data = $data === null ? $this->getNoaLastLoginCookieData() : $data;
			return setcookie(
			isset($data['name']) ? $data['name'] : 'NOALastLogin',
			isset($data['value']) ? $data['value'] : '',
			isset($data['expires']) ? $data['expires'] : time() + 360,
			isset($data['path']) ? $data['path'] : '/',
			isset($data['domain']) ? $data['domain'] : $_SERVER['SERVER_NAME']
			);
		}

		/**
		 * Generate needed data for NOALastLogin cookie
		 * @return array Assoc array containing keys: name, value, expires, path, domain.
		 */
		protected function getNoaLastLoginCookieData()
		{
			return array(
            'name'      => 'NOALastLogin',
            'value'     => gmdate("Y-m-d\TH:i:s\Z"), //current timestamp utc format
            'expires'   => time() + (60 * 60 * 24 * 7 * 2), //current timestamp + 2 week
            'path'      => '/',
        	'domain'	=> $this->getDomainName() //main domain name
			);
		}

		/**
		 * Get domain name from subdomain(if present).
		 * should return nokia.com in case of xyz.nokia.com or aa.xyz.nokia.com
		 * @return string domain name
		 */
		protected function getDomainName()
		{
			$domain = $_SERVER['SERVER_NAME'];
			if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,5})$/i', $domain, $regs))
			{
				return $regs['domain'];
			}
			return $_SERVER['SERVER_NAME'];
		}

		/**
	     * Returns the Current URL
	     * @return String the current URL
	     */
	    protected function getCurrentUrl()
	    {
		    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on'
		    ? 'https://'
		    : 'http://';
		    $currentUrl = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
		    $parts = parse_url($currentUrl);

		    // use port if non default
	    	$port =
	    	isset($parts['port']) &&
	    	(($protocol === 'http://' && $parts['port'] !== 80) ||
	    	($protocol === 'https://' && $parts['port'] !== 443))
	    	? ':' . $parts['port'] : '';

	    	$query = '';
	    	if(isset($parts['query']) && !empty($parts['query']))
	    	{
	    		$params = explode('&', $parts['query']);
		      	$qs = array();
		        foreach ($params as $param) {
			        if ($this->dropQueryParams($param)) {
	         			 $qs[] = $param;
	        		}
			    }
		     }
			 if (!empty($qs)) {
			        $query = '?'.implode($qs, '&');
			 }

	    	// rebuild the current URL
	    	return $protocol . $parts['host'] . $port . $parts['path']. $query;
	    }

	    /**
	     *  Query params created by SDK or nokia account need to be removed and retain service's queryparams.
	     *  @return boolean
	     */
	    private function dropQueryParams($param){
	    	foreach ($this->_dropqueryparams as $drop_query_param) {
      			if (strpos($param, $drop_query_param.'=') === 0) {
        			return false;
      			}
	    	}
        	return true;
	    }

		/**
		 * Create the URL for given host, path and parameters.
		 * @param $url String the url
		 * @param $path String optional path
		 * @param $params Array optional parameters
		 * @return String the URL for the given parameters
		 */
		 protected function getUrl($url, $path='', $params=array())
		 {
		   if (!$url)
		   	return false;

		   if ($path) {
		     $url .= $path;
		   }

		   if ($params) {
		     $url .= '?' . http_build_query($params, null, '&');
		   }

		   return $url;
		 }

		 /**
	     * Opaque access token decryption
	     * @param Opaque access token string
	     * @return array which contains Access Token object and Access Token Extension object.
	     */
	    public function decryptOpaqueToken($string) {
		  	//base64 url decoding of opaque access token
		  	$ciphertext = $this->base64Decode(urldecode($string));

	  		//Decrypt the first 128 bytes with the RSA1024 public key.
	  		$first128Bytes = substr($ciphertext, 0, 128);
	  		$decrypted = $this->publicKeyDecrypt($first128Bytes);

	  		if($decrypted)
	  		{
	  			//Deserialize the decrypted byte array into an OAuth2AccessToken object.
				$accessTokenObj = new OAuth2AccessToken();
				$accessTokenObj->parseFromString($decrypted);

				$legacyToken = $accessTokenObj->legacyToken();

				//If the length of the URL safe base64 decoded byte array is 256 bytes,
				//decrypt the remaining 128 bytes with the RSA1024 public key.
				$last128Bytes = substr($ciphertext, 128, 128);
				if (isset($last128Bytes))
				{
					$decryptedText = $this->publicKeyDecrypt($last128Bytes);
					//Deserialize the decrypted byte array into an OAuth2AccessTokenExtension object.
					$accessTokenExtObj = new OAuth2AccessTokenExtension();
					$accessTokenExtObj->parseFromString($decryptedText);
				}

				return array($accessTokenObj,$accessTokenExtObj);

	  		}
	  		else
	  			throw new Exception("Something went wrong in token decryption",400);
		}

		/**
		 * Decrypts data with public key
		 * @param encrypted data
		 * @return decrypted data
		 */
  		private function publicKeyDecrypt($ciphertext) {

	  		$publicKey = file_get_contents("public.key",true);
	  		$res = openssl_pkey_get_public($publicKey);
			$keyData = openssl_pkey_get_details($res);

	  		openssl_public_decrypt($ciphertext,$decrypted,$keyData['key']);
	  		return $decrypted;
		}

		/**
		 * Base64 decoding.
		 * Use:
	     *   - instead of +
	     *   _ instead of /
	     *   ! instead of =
	     *
	     * @param String base64 Url decoded string
	     */
		 protected static function base64Decode($input) {
		    	return base64_decode(strtr($input, '-_!', '+/='));
		 }

		 /**
		  * Returns list of scope strings separated by comma
		  * @param Scope value from NOAServer
		  */
		 protected function getScopeValue($scope) {
		 	if ($scope > 0) {
			 	$scopeList = array();
			 	$i = 0;
			 	while ($scope > 0){
				 	$scopeNum = $scope;
				 	$scope = $scope >> 1;
				 	$leftShift = $scope << 1;
				 	$leftShift = $scopeNum - $leftShift;
				 	if ($leftShift) {
				 		array_push($scopeList, $this->_scopeMap[$i]);
				 	}
				 	$i++;
			 	}
			 	return implode($scopeList, ",");
		 	} else {
		 		return "";
		 	}
		 }
}