<?php

// set include path to find library folder
set_include_path(realpath("./library/").PATH_SEPARATOR.get_include_path());

require_once("Nokia/Sso/WebOauth2.php");
require_once("../config.php");

// forward given jsonp parameter to logout forward page
if (isset($_GET["jsonp"]) && isset($SSO_CONFIG["logoutDoneUrl"])) {
    $SSO_CONFIG["logoutDoneUrl"] .= (strpos($SSO_CONFIG["logoutDoneUrl"], "?") ? "&" : "?")."jsonp=".$_GET["jsonp"];
}
if (isset($_GET["wrapped"]) && isset($SSO_CONFIG["logoutDoneUrl"])) {
    $SSO_CONFIG["logoutDoneUrl"] .= (strpos($SSO_CONFIG["logoutDoneUrl"], "?") ? "&" : "?")."wrapped=".$_GET["wrapped"];
}

$sso = Nokia_Sso_WebOauth2::getInstance();
$sso->setConfig($SSO_CONFIG);
$sso->endSession();
