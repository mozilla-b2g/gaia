<?php

require_once("config.php");
require_once("functions.php");

if (!function_exists("curl_init")) {
    die("CURL is not available");
}

class Http {

    /**
     * Prepare a GET request that follows redirects
     * @param string url url to request
     */
    private static function prepare($url, $headers = NULL) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        // response will be fed to a variable
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // follow redirects
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);

        if (PROXY_HOST) {
            curl_setopt($ch, CURLOPT_PROXY, PROXY_HOST .":". PROXY_PORT);
        }

        if(isset($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }

        return $ch;
    }

    /**
     * Creates a GET request that follows redirects
     * @param string url url to request
     * @return string unmodified response
     */
    public static function get($url, $headers = NULL) {
        $ch = self::prepare($url, $headers);
        $res = curl_exec($ch);
        curl_close($ch);

        if (!$res) {
            return array();
        }

        return self::cleanup(json_decode($res, TRUE));
    }

    public static function getMulti($urls) {
        $mh = curl_multi_init();
        $req = array();

        foreach ($urls as $key=>$url) {
            $ch = self::prepare($url);
            $req[$key] = $ch;
            curl_multi_add_handle($mh, $ch);
        }

        do {
            curl_multi_exec($mh, $isRunning);
            usleep(10000);
        } while ($isRunning);

        $res = array();
        foreach ($req as $key=>$ch) {
            $content = curl_multi_getcontent($ch);
            $res[$key] = $content ? self::cleanup(json_decode($content, TRUE)) : array();
            curl_multi_remove_handle($mh, $ch);
        }

        curl_multi_close($mh);

        return $res;
    }

    /**
     * create a JSON formatted response and echo it, adds required headers
     * @param array res data object to serialize
     * @return string JSON
     */
    public static function response($res) {
        // remove empty properties
        $res = self::cleanup($res);

        // create valid JSON even without data
        $body = $res ? json_encode($res) : "{}";

        // if asking for JSONP, wrap into JS function callback
        if (isset($_GET["jsonp"])) {
            $callbackFn = $_GET["jsonp"];
            // exit immediately if callback is not valid JS id
            exit_on_invalid_jsidentifier($callbackFn);
            header("Content-Type: application/javascript; charset=utf-8");
            $body = $callbackFn."($body);";
        } else {
            header("Content-Type: application/json; charset=utf-8");
        }

        if (!$res) {
            header("HTTP/1.0 204 No Content");
        }

        echo $body;
        exit;
    }

    /**
     * remove empty properties from a data object
     * purpose is to keep JSON data as small as possible
     * simplification not possible. removing an empty associative property is different from removing a numeric one

        array("A", "B", "C") --> ["A","B","C"]
        array("A", "", "C") --> {"0":"A","2":"C"}
        array(0=>"A", 1=>"B", 2=>"C") --> ["A","B","C"]
        array(0=>"A", 1=>"", 2=>"C") --> {"0":"A","2":"C"}
        array("0"=>"A", "1"=>"B", "2"=>"C") --> ["A","B","C"]
        array("0"=>"A", "1"=>"", "2"=>"C") --> {"0":"A","2":"C"}
        array("a"=>"A", "b"=>"B", "c"=>"C") --> {"a":"A","b":"B","c":"C"}
        array("a"=>"A", "b"=>"", "c"=>"C") --> {"a":"A","c":"C"}

     * @param array obj the data structure to clean up
     * @return array the cleaned data structure
     */
    private static function cleanup($obj) {
        if (!is_array($obj)) {
            return $obj;
        }

        if (!count($obj)) {
            return NULL;
        }

        // associative array
        if (array_diff_key($obj, array_keys(array_keys($obj)))) {
            $res = array();
            foreach ($obj as $k=>$v) {
                 $v = self::cleanup($v);
                 if ($v !== "" && $v !== NULL) {
                    $res[$k] = $v;
                }
            }
            return $res;
        }

        $res = array();
        for ($i = 0; $i < count($obj); $i++) {
            $res[$i] = self::cleanup($obj[$i]);
        }

        return $res;
    }
}
