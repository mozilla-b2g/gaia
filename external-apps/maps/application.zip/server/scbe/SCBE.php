<?php

require_once("../curl.php");

function get_first_type() {
    $types = get_object_types();
    if (empty($types)) {
        return "";
    }
    return $types[0];
}

function get_pair_types() {
    $types = get_object_types();
    if (count($types) != 2) {
        header("HTTP/1.0 500 Unsupported parameter");
        echo "invalid";
        exit;
    }
    return $types;
}

function get_pair_ids($ids) {
    $ids = explode(",", $ids);
    if (count($ids) != 2) {
        header("HTTP/1.0 500 Unsupported parameter");
        echo "invalid";
        exit;
    }
    return $ids;
}

function get_object_types() {
    if (!isset($_GET["objectTypes"])) {
        return array("favoritePlace");
    }
    $types = explode(",", $_GET["objectTypes"]);
    $allowed_types = array("favoritePlace", "favoriteRoute", "collection");
    if (array_diff($types, $allowed_types)) {
        header("HTTP/1.0 401 Unauthorized");
        echo "Denied Object Type";
        exit;
    }
    return $types;
}


class SCBE {

    public static $server  = "";
    public static $status  = 0;
    public static $error   = "";
    public static $request_url = "";


    private static function &buildHeaders($accessToken) {
        if (getenv("LOCAL_SCBE")) {
            $headers = array(
                "Content-Type: application/json",
                "Authorization: Basic ".base64_encode("development:development"),
                "X-SCBE-User-ID: 12345"
            );
        } else {
            $headers = array(
                "Content-Type: application/json",
                "Authorization: Bearer $accessToken"
            );
        }
        return $headers;
    }

    public static function updateObject($objType, $objJSON, $accessToken) {
        $headers =& self::buildHeaders($accessToken);
        $json = json_decode($objJSON, TRUE);
        $objId = $json["id"];
        self::$request_url = self::$server.$objType."/".$objId;
        $res = curl(array(
                    "method"  => "PUT",
                    "url"     => self::$request_url,
                    "headers" => $headers,
                    // we are sending as JSON: set raw data
                    "curlOptions" => array(CURLOPT_POSTFIELDS=>$objJSON, CURLOPT_SSLVERSION => 3)
                ));
        $res->body = self::fixJSONResponse($res->body);
        self::checkForErrors($res);
        return $res->body;
    }

    public static function getDefaultCollection($accessToken) {


    }

    public static function addObject($objType, $objJSON, $accessToken) {
        $headers =& self::buildHeaders($accessToken);

        $res = curl(array(
            "method"  => "POST",
            "url"     => self::$server.$objType,
            "headers" => $headers,
            // we are sending as JSON: set raw data
            "curlOptions" => array(CURLOPT_POSTFIELDS=>$objJSON, CURLOPT_SSLVERSION => 3)
        ));
        $res->body = self::fixJSONResponse($res->body);
        self::checkForErrors($res);
        return $res->body;
    }

    public static function removeObject($objType, $objId, $accessToken) {
        $headers =& self::buildHeaders($accessToken);
        $res = curl(array(
            "method"  => "PUT",
            "url"     => self::$server.$objType."/".$objId,
            "headers" => $headers,
            "curlOptions" => array(CURLOPT_POSTFIELDS=>'{"deleted":true}', CURLOPT_SSLVERSION => 3) // odd, but CURLOPT_POSTFIELDS is the way to add payload to PUT
        ));
        $res->body = self::fixJSONResponse($res->body);
        self::checkForErrors($res);
        return $res->body;
    }

    public static function listObjectsByQuery($objType, $query, $accessToken, $includeDeletedSince = NULL) {
        $headers =& self::buildHeaders($accessToken);
        $resultMap = array();
        $remainingObjects = 0;
        $startIndex = 0;
        do {
/*
            self::$request_url = self::$server."search?q=type%3A$objType%20$query".($includeDeletedSince ? "" :
                "%20deleted%3Afalse")."&count=max".($includeDeletedSince ? "&since=$includeDeletedSince" : "") .
                "&startIndex=$startIndex";
*/

            // deleted=false and since depend on the same variable as we need deleted=true updates
            // when we do incremental
            $deleted = $includeDeletedSince ? "" : "%26deleted%3Dfalse";
            $since = $includeDeletedSince ? "&since=$includeDeletedSince" : "";
            $request_url = self::$server."$objType?q=$query$deleted&count=max$since&startIndex=$startIndex";

            //okay I think this is buggy since deleted=false must be part of the query (so needs to be encoded)
            //self::$request_url = self::$server."$objType?q=$query&deleted=false&count=max&startIndex=$startIndex";

            $res = curl(array(
                "method"  => "GET",
                "url"     => $request_url,
                "headers" => $headers,
                "curlOptions" => array(CURLOPT_SSLVERSION => 3)
            ));
            $res->body = self::fixJSONResponse($res->body);
            self::checkForErrors($res);
            if (self::$error != "") {
                return "";
            }
            $obj = json_decode($res->body);
            if ($remainingObjects === 0 && $obj->total > $obj->count) {
                $remainingObjects = $obj->total;
            }
            $remainingObjects = $remainingObjects - $obj->count;
            $startIndex += $obj->count;
            $resultMap = array_merge($resultMap, $obj->data);
        } while ($remainingObjects > 0);

        return json_encode(array("data" => $resultMap));
    }

    public static function onCollection($opType, $objType, $colType, $objId, $colId, $accessToken) {
        $headers =& self::buildHeaders($accessToken);
        $res = curl(array(
            "method"  => $opType,
            "url"     => self::$server."$colType/$colId/$objType/$objId",
            "headers" => $headers,
            "curlOptions" => array(CURLOPT_SSLVERSION => 3)
        ));
        $res->body = self::fixJSONResponse($res->body);
        self::checkForErrors($res);
        return $res->body;
    }

    public static function test_removeAllFavs() {
        $favs = SCBE::listObjects("favoritePlace", $_SESSION["accessToken"], $_SESSION["accesstokenInfo"]["accountid"]);
        $favs = json_decode($favs);
        $removed = 0;
        $output = "";

        foreach ($favs->data as $fav) {
            $output .= "\nremoved fav" . $fav->object->id . "\n<br/>";
            $output .= self::removeFavourite($fav->object->id, $_SESSION["accessToken"]);
            $removed++;
        }
        $output .= "\n\nSUCCESS! removed $removed favs!";
        return $output;
    }

    public static function listObjects($objType, $accessToken, $accountId, $includeDeletedSince = NULL) {
        return self::listObjectsByQuery($objType, "creatorId%3D$accountId", $accessToken, $includeDeletedSince);
    }

    public static function getFromCollection($objType, $accessToken, $colId, $includeDeletedSince = NULL) {
        return self::listObjectsByQuery($objType, "collectionId%3D$colId", $accessToken, $includeDeletedSince);
    }

    public static function addToCollection($objType, $colType, $objId, $colId, $accessToken) {
        return self::onCollection("PUT", $objType, $colType, $objId, $colId, $accessToken);
    }

    public static function removeFromCollection($objType, $colType, $objId, $colId, $accessToken) {
        return self::onCollection("DELETE", $objType, $colType, $objId, $colId, $accessToken);
    }

    public static function addFavourite($favJSON, $accessToken) {
        return self::addObject("favoritePlace", $favJSON, $accessToken);
    }

    public static function removeFavourite($serverFavId, $accessToken) {
        return self::removeObject("favoritePlace", $serverFavId, $accessToken);
    }

    public static function listFavourites($accessToken, $accountId, $includeDeletedSince = NULL) {
        return self::listObjects("favoritePlace", $accountId, $accessToken, $includeDeletedSince);
    }

    // broken response body. header parts are mixed with json
    private static function fixJSONResponse($res) {
        preg_match("/\{.*\}/ms", $res, $match);
        return $match[0];
    }

    private static function checkForErrors($res) {
        $json = json_decode($res->body, TRUE);
        self::$error  = $json["errorMessage"] ? $json["errorMessage"] : "";
        self::$status = $res->status;
    }
}
