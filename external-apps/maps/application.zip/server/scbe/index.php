<?php

// set include path to find library folder
set_include_path(realpath("./../sso/library/").PATH_SEPARATOR.get_include_path());

require_once("Nokia/Sso/WebOauth2.php");
require_once("../config.php");
require_once("SCBE.php");
require_once("../Place.php");
require_once("../security.php");

SCBE::$server = $CONFIG["SCBE_URL"];

//*** do some dependency injection
$sso = Nokia_Sso_WebOauth2::getInstance();
$sso->setConfig($SSO_CONFIG);
$sso->startSession(); // start a session if storage type is 'phpsession'
$sso->createSession();

checkAppIdAndCode();
checkCsrfToken();

function isTestEnv() {
    return getenv('MH5_ENV') === 'test' || getenv('MH5_ENV') === 'dv';
}

if (isset($_GET["delete"])) {
    $resJson = SCBE::removeObject(get_first_type(), $_GET["delete"], $_SESSION["accessToken"]);
} elseif (isset($_GET["add"])) {
    $resJson = SCBE::addObject(get_first_type(), $_GET["add"], $_SESSION["accessToken"]);
} elseif (isset($_GET["update"])) {
    $resJson = SCBE::updateObject(get_first_type(), $_GET["update"], $_SESSION["accessToken"]);
} elseif ($_GET["defaultCollection"]) {
    $resJson = SCBE::getFromCollection($_GET["objectTypes"], $_SESSION["accessToken"], "Cd");
}  elseif ($_GET["add_to_collection"]) {
    $ids = get_pair_ids($_GET["add_to_collection"]);
    $types = get_object_types();
    $resJson = SCBE::addToCollection($types[0],$types[1], $ids[0], $ids[1], $_SESSION["accessToken"]);
} elseif ($_GET["remove_from_collection"]) {
    $ids = get_pair_ids($_GET["remove_from_collection"]);
    $types = get_object_types();
    $resJson = SCBE::removeFromCollection($types[0],$types[1], $ids[0], $ids[1], $_SESSION["accessToken"]);
} elseif ($_GET["get_from_collection"]) {
    $resJson = SCBE::getFromCollection($_GET["objectTypes"], $_SESSION["accessToken"], $_GET["get_from_collection"]);
} elseif (isTestEnv() && isset($_GET["test_removeAllFavs"])) {
    echo SCBE::test_removeAllFavs();
    exit;
} else {
    // defaults to $_GET["list"]
    $type = get_first_type();
    $resJson = SCBE::listObjects($type, $_SESSION["accessToken"], $_SESSION["accesstokenInfo"]["accountid"], $_GET["deletedSince"]);
}


if (SCBE::$error) {
    $error = SCBE::$error;
    $debug_url = SCBE::$request_url;
    if (isset($_GET["jsonp"])) {
        header("Content-Type: application/javascript; charset=utf-8");
        echo $_GET["jsonp"]."({\"error\":\"$error\", \"debug_url\": \"$debug_url\"});";
        exit;
    }
    header("HTTP/1.0 ".SCBE::$status." Bad Request");
    echo SCBE::$error;
    exit;
}


$resJson = $resJson ? $resJson : "{}";

if (isset($_GET["jsonp"])) {
    header("Content-Type: application/javascript; charset=utf-8");
    echo $_GET["jsonp"]."($resJson);";
} else {
    header("Content-Type: application/json; charset=utf-8");
    echo $resJson;
}
