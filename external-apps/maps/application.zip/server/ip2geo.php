<?php
require("curl.php");

$ip = $_SERVER["HTTP_X_FORWARDED_FOR"] ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];

echo json_encode(curl(array(
    "method" => "GET",
    "url" => "http://maps.nokia.com/services/iplookup/get",
    "timeout" => 5,
    "headers" => array(
        "Remote-Addr: $ip",
        "X-Forwarded-For: $ip"
    )
)));

?>