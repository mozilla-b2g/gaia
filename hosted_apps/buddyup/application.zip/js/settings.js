'use strict';

/* exported Settings */

/* TODO: Replace with dev and prod files selected with Grunt */

var Settings = {
  BASE_SERVER: 'https://support.mozilla.org'
};
